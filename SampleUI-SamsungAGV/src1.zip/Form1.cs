﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using Newtonsoft.Json;
using System.IO;
using GroupDocs.Parser.Data;
using GroupDocs.Parser.Options;
using GroupDocs.Parser;
using System.Net.Http;
using System.Threading;
using System.Resources;

namespace SampleUI_SamsungAGV
{
    public partial class Form1 : Form
    {

        bool rt = false, rt2 = false;
        private System.Drawing.Point _mouseLoc;
        private double batScale(double value, double min, double max, double minScale, double maxScale)
        {
            double scaled = minScale + (double)(value - min) / (max - min) * (maxScale - minScale);
            return scaled;
        }

        System.Drawing.Point location = System.Drawing.Point.Empty;
        public int xAgv, yAgv, interval = 5, cntStop = 0, cntStop4 = 0;
        public int posX, posY, testButton = 0, agvAddress = 1;
        public long jobId;
        public List<AGVDataModel> AGVData = new List<AGVDataModel>();
        public List<AGVStatusModel> AGVStatus = new List<AGVStatusModel>();
        public string agvState, agvName = "AGV-1", agvStatus,agvRoute,agvRfid, statusDelivery;
        
        public int waitingTime = 0;
        public bool endFlag = false;
        class RequestData
        {
            public string command { get; set; }
            public int serialNumber { get; set; }
        }
        class ResponseData
        {
            public string errMark { get; set; }
            public List<List<dynamic>> msg { get; set; }        // add command checker
            public string command { get; set; }
        }
        public class AGVDeviceModel
        {
            public string ID { get; set; }
            public string Name { get; set; }
            public string Status { get; set; }
            public AGVDeviceModel(string agvId, string agvName,string status)
            {
                this.ID = agvId;
                this.Name = agvName;
                this.Status=status;
            }
        }
        public class AGVStatusModel
        {
            //public string ID { get; set; }
            public string Name { get; set; }
            public string State { get; set; }
            public string Status { get; set; }
            public AGVStatusModel(string agvName,string power, string status)
            {
                //this.ID = agvId;
                this.Name = agvName;
                this.State = power;
                this.Status = status;
            }
        }
        public class AGVErrorModel
        {
            public string ID { get; set; }
            public string Name { get; set; }
            public string ErrorCode { get; set; }
            public AGVErrorModel(string agvId, string agvName, string errorCode)
            {
                this.ID = agvId;
                this.Name = agvName;
                this.ErrorCode = errorCode;
            }
        }
        public class AGVDataModel
        {
            public string Time { get; set; }
            public string Name { get; set; }
            public string Station { get; set; }
            public string Status { get; set; }
            public AGVDataModel(string time,string agvname, string deliv, string status )
            {
                this.Time = time;
                this.Name = agvname;
                this.Station = deliv;
                this.Status = status;
            }
        }
        private async void callAPI()
        {
            //Console.WriteLine("\t Start Call API");
            string[] arrayMachine = new string[] { "SMD_01", "SMD_02", "SMD_03", "SMD_04", "SMD_05", "SMD_06" };
            string[] arrayPosition = new string[] {"ENDING","STANDBY", "GO TO LINE", "GO TO LINE","PARKING AREA", "HOME","WIP AREA", "WIP-IN-1", "WIP-IN-2",
                                                             "WIP-IN-3", "WIP-IN-4","WIP-IN-5", "WIP-OUT-1", "LOW SPEED", "GO TO LINE", "LINE AREA",tbox1.Text,tbox1.Text,
                                                             tbox2.Text,tbox2.Text,tbox3.Text,tbox3.Text,tbox4.Text,tbox4.Text,tbox5.Text,tbox5.Text ,"ENDING"};
            string[] arrayRFID = new string[] { "9","0", "1", "2", "4", "5", "19", "20", "21", "22", "23", "24", "10", "11", "31", "32", "33", "34",
                                                   "15", "16","37", "38","39", "40","41", "42" ,"8"};
            int[] arrayRfidLoc_X = new int[] {rfid9.Location.X,0,rfid1.Location.X,rfid2.Location.X,rfid4.Location.X,rfid5.Location.X, rfid19.Location.X,rfid20.Location.X,rfid21.Location.X,
                                              rfid22.Location.X,rfid23.Location.X,rfid24.Location.X,rfid10.Location.X,rfid11.Location.X,rfid31.Location.X,rfid32.Location.X,rfid33.Location.X, 
                                              rfid34.Location.X,rfid15.Location.X,rfid16.Location.X,rfid37.Location.X,rfid38.Location.X,rfid39.Location.X,rfid40.Location.X,rfid41.Location.X,
                                              rfid42.Location.X,rfid8.Location.X};
            int[] arrayRfidLoc_Y = new int[] {rfid9.Location.Y,0,rfid1.Location.Y,rfid2.Location.Y,rfid4.Location.Y,rfid5.Location.Y, rfid19.Location.Y,rfid20.Location.Y,rfid21.Location.Y,
                                              rfid22.Location.Y,rfid23.Location.Y,rfid24.Location.Y,rfid10.Location.Y,rfid11.Location.Y,rfid31.Location.Y,rfid32.Location.Y,rfid33.Location.Y,
                                              rfid34.Location.Y,rfid15.Location.Y,rfid16.Location.Y,rfid37.Location.Y,rfid38.Location.Y,rfid39.Location.Y,rfid40.Location.Y,rfid41.Location.Y,
                                              rfid42.Location.Y,rfid8.Location.Y};

            //Console.Write("Position : {0} X : {1} Y : {2}", arrayRFID, arrayRfidLoc_X, arrayRfidLoc_Y);

            ResponseData data = await API("missionC.missionGetActiveList()");
            if (data.errMark == "OK")
            {
                List<AGVDataModel> showData = new List<AGVDataModel>();
                for (int i = 0; i < data.msg.Count; i++)
                {
                    string agvTime = UnixTimeStampToDateTime(data.msg[i][11]).ToString();
                    statusDelivery = data.msg[i][10];                   
                    if (jobId.ToString() != "" && statusDelivery == "执行")
                    {
                        
                        statusDelivery = "RUNNING";
                        jobId = data.msg[i][0];
                        long[] arrayJobId = new long[] {data.msg[0][0], data.msg[1][0], data.msg[2][0], data.msg[3][0], data.msg[4][0],
                                                data.msg[5][0], data.msg[6][0], data.msg[7][0], data.msg[8][0],data.msg[9][0] };

                        long maxJobid = arrayJobId.Last();
                        long searchJobid = jobId;
                        long indexJob = Array.IndexOf(arrayJobId, searchJobid);
                        //foreach (var item in arrayJobId)
                        //{
                        //    Console.WriteLine("Read Job ID : {0} JobId : {1} indexJob : {2}", item.ToString(), jobId, indexJob);
                        //    Console.WriteLine("RFID Location X: {0}", rfid1.Location.X);

                        //}
                        AGVDataModel temp = new AGVDataModel(agvTime, agvName, data.msg[i][1].ToString(), statusDelivery);
                        showData.Add(temp);
                        string searchString = data.msg[(int)indexJob][1];           //Read first call jobID the search Name
                        int index = Array.IndexOf(arrayMachine, searchString);
                        //Console.WriteLine("The first occurrence of \"{0}\" is at index {1}. statusDelivery : {2}", searchString, index, statusDelivery);
                        if (index == 0)
                        {
                            send1.Visible = true; send2.Visible = false; send3.Visible = false; send4.Visible = false; send5.Visible = false; send6.Visible = false;
                            standby1.Visible = false; standby2.Visible = true; standby3.Visible = true; standby4.Visible = true; standby5.Visible = true; standby6.Visible = true;
                            wip1.Visible = true; wip2.Visible = false; wip3.Visible = false; wip4.Visible = false; wip5.Visible = false; wip6.Visible = false;

                        }
                        else if (index == 1)
                        {
                            send1.Visible = false; send2.Visible = true; send3.Visible = false; send4.Visible = false; send5.Visible = false; send6.Visible = false;
                            standby1.Visible = true; standby2.Visible = false; standby3.Visible = true; standby4.Visible = true; standby5.Visible = true; standby6.Visible = true;
                            wip1.Visible = false; wip2.Visible = true; wip3.Visible = false; wip4.Visible = false; wip5.Visible = false; wip6.Visible = false;
                        }
                        else if (index == 2)
                        {
                            send1.Visible = false; send2.Visible = false; send3.Visible = true; send4.Visible = false; send5.Visible = false; send6.Visible = false;
                            standby1.Visible = true; standby2.Visible = true; standby3.Visible = false; standby4.Visible = true; standby5.Visible = true; standby6.Visible = true;
                            wip1.Visible = false; wip2.Visible = false; wip3.Visible = true; wip4.Visible = false; wip5.Visible = false; wip6.Visible = false;
                        }
                        else if (index == 3)
                        {
                            send1.Visible = false; send2.Visible = false; send3.Visible = false; send4.Visible = true; send5.Visible = false; send6.Visible = false;
                            standby1.Visible = true; standby2.Visible = true; standby3.Visible = true; standby4.Visible = false; standby5.Visible = true; standby6.Visible = true;
                            wip1.Visible = false; wip2.Visible = false; wip3.Visible = false; wip4.Visible = true; wip5.Visible = false; wip6.Visible = false;
                        }
                        else if (index == 4)
                        {
                            send1.Visible = false; send2.Visible = false; send3.Visible = false; send4.Visible = false; send5.Visible = true; send6.Visible = false;
                            standby1.Visible = true; standby2.Visible = true; standby3.Visible = true; standby4.Visible = true; standby5.Visible = false; standby6.Visible = true;
                            wip1.Visible = false; wip2.Visible = false; wip3.Visible = false; wip4.Visible = false; wip5.Visible = true; wip6.Visible = false;
                        }
                        else if (index == 5)
                        {
                            send1.Visible = false; send2.Visible = false; send3.Visible = false; send4.Visible = false; send5.Visible = false; send6.Visible = true;
                            standby1.Visible = true; standby2.Visible = true; standby3.Visible = true; standby4.Visible = true; standby5.Visible = true; standby6.Visible = false;
                            wip1.Visible = false; wip2.Visible = false; wip3.Visible = false; wip4.Visible = false; wip5.Visible = false; wip6.Visible = true;
                        }
                        else
                        {
                            send1.Visible = false; send2.Visible = false; send3.Visible = false; send4.Visible = false; send5.Visible = false; send6.Visible = false;
                            standby1.Visible = true; standby2.Visible = true; standby3.Visible = true; standby4.Visible = true; standby5.Visible = true; standby6.Visible = true;
                            wip1.Visible = false; wip2.Visible = false; wip3.Visible = false; wip4.Visible = false; wip5.Visible = false; wip6.Visible = false;
                        }
                    }
                    else if (jobId.ToString() != "" && statusDelivery == "放弃")
                    {
                        statusDelivery = "HOLD";
                        AGVDataModel temp = new AGVDataModel(agvTime, agvName, data.msg[i][1].ToString(), statusDelivery);
                        //showData.Add(temp);
                    }
                    else if (jobId.ToString() != "" && statusDelivery == "正常结束")
                    {
                        statusDelivery = "FINISH";
                        AGVDataModel temp = new AGVDataModel(agvTime, agvName, data.msg[i][1].ToString(), statusDelivery);
                        showData.Add(temp);
                        //send1.Visible = false; send2.Visible = false; send3.Visible = false; send4.Visible = false; send5.Visible = false; send6.Visible = false;
                        //agvIcon.Visible = false;
                    }
                    else
                    {

                    }
                }
                gridViewDS.DataSource = showData;
            }

            data = await API("devC.getCarList()");
            if (data.errMark == "OK")
            {
                List<AGVStatusModel> showData = new List<AGVStatusModel>();
                for (int i = 0; i < data.msg.Count; i++)
                {
                    double readVoltage = data.msg[i][4], minVoltage = 22.5, maxVoltage = 26.5;
                    if (readVoltage > minVoltage && readVoltage < maxVoltage)
                    {
                        readVoltage = data.msg[i][4];
                        batteryLevel1.Visible = true;
                    }
                    else if (readVoltage > maxVoltage)
                    {
                        readVoltage = maxVoltage;
                        batteryLevel1.Visible = true;
                    }
                    else if (readVoltage < minVoltage)
                    {
                        readVoltage = minVoltage;
                        batteryLevel1.Visible = false;
                    }
                    else
                    {
                        batteryLevel1.Visible = true;
                    }
                    double batOne = batScale(readVoltage, minVoltage, maxVoltage, 0, 100);
                    double power = data.msg[i][7];
                    batteryLevel1.Value = (int)power;
                    batValue1.Text = power.ToString();

                    //"车" Read RFID and detail Car activity
                    double dataStatus = data.msg[i][15], dataRute = data.msg[i][31], dataRfid = data.msg[i][33], readAddress = data.msg[i][0];
                    string readType = data.msg[i][2];
                    string searchRFID = dataRfid.ToString();
                    Console.Write(searchRFID);
                    int indexRFID = Array.IndexOf(arrayRFID, searchRFID);
                    
                    //Console.WriteLine("The first occurrence of \"{0}\" is at index {1}", searchRFID, indexRFID);
                    
                    agvStatus = dataStatus.ToString();
                    agvRoute = dataRute.ToString();
                    agvRfid = dataRfid.ToString();

                    Console.WriteLine("\n data RFID : {0} Destination : {1} dataRute : {2} dataStatus : {3} X : {4} Y : {5}"
                                        , dataRfid, arrayPosition[indexRFID], dataRute, dataStatus,agvIcon.Left,agvIcon.Top);
                    if (readAddress == agvAddress && readType == "车")
                    {
                        if (dataStatus == 0)
                        {
                            agvStatus = "STOP";
                        }
                        else if (dataStatus == 1)
                        {
                            agvStatus = "PAUSE";
                        }
                        else if (dataStatus == 2)
                        {
                            agvStatus = "RUN";
                        }
                        else
                        {

                        }

                        if (dataRute == 1 || dataRute == 2 || dataRute == 3 || dataRute == 4 || dataRute == 5)
                        {
                            agvRoute = "GO TO LINE";
                            if (dataRfid == 11)
                            {
                                labelPosition.Text = agvRoute;
                            }
                            else
                            {
                                labelPosition.Text = arrayPosition[indexRFID];
                            }

                        }
                        else if ((dataRute == 1 || dataRute == 2 || dataRute == 3 || dataRute == 4 || dataRute == 5) && dataRfid == 1)
                        {
                            wip1.Visible = false; wip2.Visible = false; wip3.Visible = false; wip4.Visible = false; wip5.Visible = false; wip6.Visible = false;
                        }

                        else if (dataRute == 20 && (dataRfid == 32 || dataRfid == 31 || dataRfid == 1 || dataRfid == 2))
                        {
                            agvRoute = "GO TO WIP";
                            labelPosition.Text = agvRoute;
                        }
                        else if (dataRute == 20 && dataRfid == 10)
                        {
                            wipFull1.Visible = true;
                        }
                        else if (dataRute == 20)
                        {
                            agvRoute = "GO HOME";
                            //labelPosition.Text = agvRoute;
                            if (dataRfid == 5)
                            {
                                labelPosition.Text = arrayPosition[indexRFID];
                                agvHome1.Visible = true;
                                agvIcon.Visible = false;
                                send1.Visible = false; send2.Visible = false; send3.Visible = false; send4.Visible = false; send5.Visible = false; send6.Visible = false;
                                standby1.Visible = true; standby2.Visible = true; standby3.Visible = true; standby4.Visible = true; standby5.Visible = true; standby6.Visible = true;
                                wip1.Visible = false; wip2.Visible = false; wip3.Visible = false; wip4.Visible = false; wip5.Visible = false; wip6.Visible = false;
                                Console.WriteLine("cok");
                            }
                            wipFull1.Visible = false;
                            wipFull2.Visible = false;
                        }
                        else
                        {
                            agvRoute = "STANDBY";
                            labelPosition.Text = arrayPosition[indexRFID];
                        }


                        if ((dataRfid == 1 || dataRfid == 11 || dataRfid == 31) && (dataRute == 1 || dataRute == 2 || dataRute == 3 || dataRute == 4 || dataRute == 5))
                        {
                            agvIcon.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
                            agvIcon.Visible = true;
                            agvIcon.Left = arrayRfidLoc_X[indexRFID];
                            agvIcon.Top = arrayRfidLoc_Y[indexRFID];
                            Console.WriteLine("cok berangkat");
                        }
                        else if ((dataRfid == 31) && dataRute == 20)
                        {
                            agvIcon.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
                            agvIcon.Visible = true;
                            agvIcon.Left = arrayRfidLoc_X[indexRFID];
                            agvIcon.Top = arrayRfidLoc_Y[indexRFID];
                            Console.WriteLine("cok pulang");
                        }
                        else if ((dataRfid != 0 && dataRfid != 5) && dataRute == 20)
                        {
                            //agvIcon.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
                            agvIcon.Visible = true;
                            agvIcon.Left = arrayRfidLoc_X[indexRFID];
                            agvIcon.Top = arrayRfidLoc_Y[indexRFID];
                            Console.WriteLine("cok mboh");
                        }
                        else
                        {
                            //agvIcon.Visible = false;
                            Console.WriteLine("cok else");
                            AGVStatusModel temp = new AGVStatusModel(agvName, agvState, agvStatus.ToString());
                            showData.Add(temp);
                        }
                    }
                }
                List<AGVErrorModel> showError = new List<AGVErrorModel>();
                for (int i = 0; i < data.msg.Count; i++)
                {
                    AGVErrorModel temp = new AGVErrorModel(data.msg[i][0].ToString(), agvName, data.msg[i][15].ToString());
                    showError.Add(temp);
                }

                gridViewStatus.DataSource = showData;
                gridViewError.DataSource = showError;
            }

            data = await API("devC.getDeviceList()");
            if (data.errMark == "OK")
            {
                List<AGVDeviceModel> showDevice = new List<AGVDeviceModel>();
                for (int i = 0; i < data.msg.Count; i++)
                {
                    double agvAddress = data.msg[i][3], offTime = data.msg[i][6];

                    if (agvAddress == 1 && offTime >= 3)
                    {
                        agvState = "OFF";
                        //Console.WriteLine("percent : {0}", offTime);
                    }
                    else if (agvAddress == 1 && offTime > 0.5)
                    {
                        agvState = "ON";
                    }
                    else
                    {
                        //agvState = "OFF";
                    }
                }
            }
            callAPI();
        }
        
        private async void timer5_Tick(object sender, EventArgs e)
        {
            waitingTime += 1;
            //Console.Write("Position : {0} X : {1} Y : {2}", arrayPosition.Length, arrayRfidLoc_X.Length, arrayRfidLoc_Y.Length);
            //Console.WriteLine(waitingTime);
        }

        [Obsolete]
        public Form1()
        {
            //this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            InitializeComponent();
            //xAgv = agvIcon.Location.X;
            //yAgv = agvIcon.Location.Y;
            gridViewStatus.DataSource = AGVStatus;
            gridViewDS.DataSource = AGVData;
            AutoClosingMessageBox.Show("Connecting to The server","SYSTEM INFO", 10000);
            callAPI();
        }

        private async Task<ResponseData> API(string command)
        {
            var cmd = new RequestData();
            cmd.command = command;
            cmd.serialNumber = 0;

            var json = JsonConvert.SerializeObject(cmd);
            //Console.Write(json);
            var data = new StringContent(json, Encoding.UTF8, "application/json");
            var url = "http://localhost:8000/req";
            var client = new HttpClient();


            var response = await client.PostAsync(url, data);
            ResponseData ret;
            while (true)
            {
                 ret = JsonConvert.DeserializeObject<ResponseData>(response.Content.ReadAsStringAsync().Result);
                if(ret.command == cmd.command)
                {
                    break;
                }
            }
            return ret;
            //Console.WriteLine("Error Message: {0}", ret.errMark);
            //Console.WriteLine("Message: {0}", ret.msg);
            //Console.WriteLine("IP Robot: {0}", ret.msg[0][5][0]);
            //Console.WriteLine(ret);
            //string result = response.Content.ReadAsStringAsync().Result;
            ////Console.WriteLine(result);
        }
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                int dx = e.Location.X - _mouseLoc.X;
                int dy = e.Location.Y - _mouseLoc.Y;
                this.Location = new System.Drawing.Point(this.Location.X + dx, this.Location.Y + dy);
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            _mouseLoc = e.Location;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            dateLabel.Text = DateTime.Now.ToString();
        }

        int cntMove = 0;
        private void timer2_Tick(object sender, EventArgs e)
        {
            cntMove += 1;
        }

        private void timer3_Tick(object sender, EventArgs e)
        {

        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            
 
        }

        private void detailError_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Text = "Detail Error History";
            form2.HelpButton = true;
            form2.FormBorderStyle = FormBorderStyle.FixedDialog;
            form2.StartPosition = FormStartPosition.CenterScreen;
            form2.ShowDialog();


        }
        private void detailDelivery_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Text = "Detail Delivery Status";
            form3.HelpButton = true;
            form3.FormBorderStyle = FormBorderStyle.FixedDialog;
            form3.StartPosition = FormStartPosition.CenterScreen;
            form3.ShowDialog();
            
        }

        public static DateTime UnixTimeStampToDateTime(double unixTimeStamp)
        {
            // Unix timestamp is seconds past epoch
            DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            dateTime = dateTime.AddSeconds(unixTimeStamp).ToLocalTime();
            return dateTime;

        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
