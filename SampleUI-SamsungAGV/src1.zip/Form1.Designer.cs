﻿
namespace SampleUI_SamsungAGV
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Obsolete]
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.detailDeliveryButton = new Bunifu.Framework.UI.BunifuThinButton2();
            this.closeButton = new Bunifu.Framework.UI.BunifuThinButton2();
            this.detailErrorButton = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuPanel1 = new Bunifu.UI.WinForms.BunifuPanel();
            this.batValue1 = new System.Windows.Forms.Label();
            this.batteryLevel1 = new Bunifu.UI.WinForms.BunifuProgressBar();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.gridViewError = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.Column_TimeError = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column_AGV_Error = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column_Message = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.gridViewDS = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.Column_Time_Deliv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column_AGV_Delivery = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column_Delivery = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridViewStatus = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.Battery = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.bunifuPanel2 = new Bunifu.UI.WinForms.BunifuPanel();
            this.agvIcon = new System.Windows.Forms.PictureBox();
            this.rfid2 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.rfid11 = new System.Windows.Forms.TextBox();
            this.rfid19 = new System.Windows.Forms.TextBox();
            this.rfid4 = new System.Windows.Forms.TextBox();
            this.rfid41 = new System.Windows.Forms.TextBox();
            this.rfid39 = new System.Windows.Forms.TextBox();
            this.rfid37 = new System.Windows.Forms.TextBox();
            this.rfid15 = new System.Windows.Forms.TextBox();
            this.rfid33 = new System.Windows.Forms.TextBox();
            this.rfid32 = new System.Windows.Forms.TextBox();
            this.rfid9 = new System.Windows.Forms.TextBox();
            this.rfid10 = new System.Windows.Forms.TextBox();
            this.rfid25 = new System.Windows.Forms.TextBox();
            this.rfid24 = new System.Windows.Forms.TextBox();
            this.rfid23 = new System.Windows.Forms.TextBox();
            this.rfid22 = new System.Windows.Forms.TextBox();
            this.rfid21 = new System.Windows.Forms.TextBox();
            this.rfid20 = new System.Windows.Forms.TextBox();
            this.stanbyLine1 = new System.Windows.Forms.PictureBox();
            this.rfid8 = new System.Windows.Forms.TextBox();
            this.tbox12 = new System.Windows.Forms.TextBox();
            this.tbox11 = new System.Windows.Forms.TextBox();
            this.tbox10 = new System.Windows.Forms.TextBox();
            this.tbox9 = new System.Windows.Forms.TextBox();
            this.tbox8 = new System.Windows.Forms.TextBox();
            this.tbox7 = new System.Windows.Forms.TextBox();
            this.rfid42 = new System.Windows.Forms.TextBox();
            this.rfid40 = new System.Windows.Forms.TextBox();
            this.rfid38 = new System.Windows.Forms.TextBox();
            this.rfid16 = new System.Windows.Forms.TextBox();
            this.rfid34 = new System.Windows.Forms.TextBox();
            this.rfid31 = new System.Windows.Forms.TextBox();
            this.rfid1 = new System.Windows.Forms.TextBox();
            this.homeBox = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.wipOut2 = new System.Windows.Forms.TextBox();
            this.wipOut1 = new System.Windows.Forms.TextBox();
            this.wipIn6 = new System.Windows.Forms.TextBox();
            this.wipIn5 = new System.Windows.Forms.TextBox();
            this.wipIn4 = new System.Windows.Forms.TextBox();
            this.wipIn3 = new System.Windows.Forms.TextBox();
            this.wipIn2 = new System.Windows.Forms.TextBox();
            this.wipIn1 = new System.Windows.Forms.TextBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.tbox1 = new System.Windows.Forms.TextBox();
            this.tbox2 = new System.Windows.Forms.TextBox();
            this.tbox3 = new System.Windows.Forms.TextBox();
            this.tbox4 = new System.Windows.Forms.TextBox();
            this.tbox5 = new System.Windows.Forms.TextBox();
            this.tbox6 = new System.Windows.Forms.TextBox();
            this.stopLine3 = new System.Windows.Forms.PictureBox();
            this.stopLine2 = new System.Windows.Forms.PictureBox();
            this.goLine2 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.SMD07 = new System.Windows.Forms.PictureBox();
            this.SMD01 = new System.Windows.Forms.PictureBox();
            this.TNP02 = new System.Windows.Forms.PictureBox();
            this.TNP01 = new System.Windows.Forms.PictureBox();
            this.TNP03 = new System.Windows.Forms.PictureBox();
            this.SMD09 = new System.Windows.Forms.PictureBox();
            this.SMD08 = new System.Windows.Forms.PictureBox();
            this.SMD06 = new System.Windows.Forms.PictureBox();
            this.SMD05 = new System.Windows.Forms.PictureBox();
            this.SMD04 = new System.Windows.Forms.PictureBox();
            this.SMD02 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.standbyLine2 = new System.Windows.Forms.PictureBox();
            this.standbyLine3 = new System.Windows.Forms.PictureBox();
            this.standby5 = new System.Windows.Forms.PictureBox();
            this.SMD03 = new System.Windows.Forms.PictureBox();
            this.standby3 = new System.Windows.Forms.PictureBox();
            this.standby2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.standby6 = new System.Windows.Forms.PictureBox();
            this.send6 = new System.Windows.Forms.PictureBox();
            this.send5 = new System.Windows.Forms.PictureBox();
            this.send3 = new System.Windows.Forms.PictureBox();
            this.send2 = new System.Windows.Forms.PictureBox();
            this.standby1 = new System.Windows.Forms.PictureBox();
            this.send1 = new System.Windows.Forms.PictureBox();
            this.goLine1 = new System.Windows.Forms.PictureBox();
            this.idleSmd1 = new System.Windows.Forms.PictureBox();
            this.standbyWip = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rfid5 = new System.Windows.Forms.TextBox();
            this.agvLabel2 = new System.Windows.Forms.Label();
            this.agvLabel1 = new System.Windows.Forms.Label();
            this.agvHome2 = new System.Windows.Forms.PictureBox();
            this.agvHome1 = new System.Windows.Forms.PictureBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.wipFull2 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.wipFull1 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.wip1 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.labelPosition = new System.Windows.Forms.Label();
            this.wip2 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.wip3 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.wip4 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.wip5 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.wip6 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.standby4 = new System.Windows.Forms.PictureBox();
            this.send4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.stopLine1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.bunifuPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.bunifuPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.agvIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stanbyLine1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopLine3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopLine2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goLine2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TNP02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TNP01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TNP03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.standbyLine2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.standbyLine3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.send6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.send5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.send3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.send2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.send1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goLine1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.idleSmd1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.standbyWip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.agvHome2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agvHome1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wipFull2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wipFull1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.send4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopLine1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.AllowParentOverrides = false;
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.CursorType = null;
            this.bunifuLabel6.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bunifuLabel6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bunifuLabel6.Location = new System.Drawing.Point(661, 10);
            this.bunifuLabel6.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(0, 0);
            this.bunifuLabel6.TabIndex = 4;
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopRight;
            this.bunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("DDTW00-CondensedSemiBold", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(709, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(501, 29);
            this.label1.TabIndex = 7;
            this.label1.Text = "SAMSUNG - AGV MONITORING SYSTEM";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 500;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 50;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // timer5
            // 
            this.timer5.Enabled = true;
            this.timer5.Interval = 1000;
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(25, 6);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(192, 43);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 138;
            this.pictureBox7.TabStop = false;
            // 
            // detailDeliveryButton
            // 
            this.detailDeliveryButton.ActiveBorderThickness = 1;
            this.detailDeliveryButton.ActiveCornerRadius = 20;
            this.detailDeliveryButton.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.detailDeliveryButton.ActiveForecolor = System.Drawing.Color.White;
            this.detailDeliveryButton.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.detailDeliveryButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.detailDeliveryButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("detailDeliveryButton.BackgroundImage")));
            this.detailDeliveryButton.ButtonText = "Detail Delivery";
            this.detailDeliveryButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.detailDeliveryButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.detailDeliveryButton.ForeColor = System.Drawing.Color.SeaGreen;
            this.detailDeliveryButton.IdleBorderThickness = 1;
            this.detailDeliveryButton.IdleCornerRadius = 20;
            this.detailDeliveryButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.detailDeliveryButton.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.detailDeliveryButton.IdleLineColor = System.Drawing.Color.Transparent;
            this.detailDeliveryButton.Location = new System.Drawing.Point(1623, 9);
            this.detailDeliveryButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.detailDeliveryButton.Name = "detailDeliveryButton";
            this.detailDeliveryButton.Size = new System.Drawing.Size(110, 40);
            this.detailDeliveryButton.TabIndex = 6;
            this.detailDeliveryButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.detailDeliveryButton.Click += new System.EventHandler(this.detailDelivery_Click);
            // 
            // closeButton
            // 
            this.closeButton.ActiveBorderThickness = 1;
            this.closeButton.ActiveCornerRadius = 20;
            this.closeButton.ActiveFillColor = System.Drawing.Color.Crimson;
            this.closeButton.ActiveForecolor = System.Drawing.Color.Red;
            this.closeButton.ActiveLineColor = System.Drawing.Color.Crimson;
            this.closeButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.closeButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("closeButton.BackgroundImage")));
            this.closeButton.ButtonText = "X";
            this.closeButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeButton.ForeColor = System.Drawing.Color.White;
            this.closeButton.IdleBorderThickness = 1;
            this.closeButton.IdleCornerRadius = 20;
            this.closeButton.IdleFillColor = System.Drawing.Color.Red;
            this.closeButton.IdleForecolor = System.Drawing.Color.White;
            this.closeButton.IdleLineColor = System.Drawing.Color.Transparent;
            this.closeButton.Location = new System.Drawing.Point(1865, 10);
            this.closeButton.Margin = new System.Windows.Forms.Padding(4);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(44, 39);
            this.closeButton.TabIndex = 2;
            this.closeButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // detailErrorButton
            // 
            this.detailErrorButton.ActiveBorderThickness = 1;
            this.detailErrorButton.ActiveCornerRadius = 20;
            this.detailErrorButton.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.detailErrorButton.ActiveForecolor = System.Drawing.Color.White;
            this.detailErrorButton.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.detailErrorButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.detailErrorButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("detailErrorButton.BackgroundImage")));
            this.detailErrorButton.ButtonText = "Detail Error";
            this.detailErrorButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.detailErrorButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.detailErrorButton.ForeColor = System.Drawing.Color.SeaGreen;
            this.detailErrorButton.IdleBorderThickness = 1;
            this.detailErrorButton.IdleCornerRadius = 20;
            this.detailErrorButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.detailErrorButton.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.detailErrorButton.IdleLineColor = System.Drawing.Color.Transparent;
            this.detailErrorButton.Location = new System.Drawing.Point(1747, 9);
            this.detailErrorButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.detailErrorButton.Name = "detailErrorButton";
            this.detailErrorButton.Size = new System.Drawing.Size(110, 40);
            this.detailErrorButton.TabIndex = 5;
            this.detailErrorButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.detailErrorButton.Click += new System.EventHandler(this.detailError_Click);
            // 
            // bunifuPanel1
            // 
            this.bunifuPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bunifuPanel1.BackgroundColor = System.Drawing.Color.White;
            this.bunifuPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel1.BackgroundImage")));
            this.bunifuPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.bunifuPanel1.BorderRadius = 3;
            this.bunifuPanel1.BorderThickness = 1;
            this.bunifuPanel1.Controls.Add(this.batValue1);
            this.bunifuPanel1.Controls.Add(this.batteryLevel1);
            this.bunifuPanel1.Controls.Add(this.pictureBox6);
            this.bunifuPanel1.Controls.Add(this.label17);
            this.bunifuPanel1.Controls.Add(this.gridViewError);
            this.bunifuPanel1.Controls.Add(this.dateLabel);
            this.bunifuPanel1.Controls.Add(this.label4);
            this.bunifuPanel1.Controls.Add(this.label3);
            this.bunifuPanel1.Controls.Add(this.label2);
            this.bunifuPanel1.Controls.Add(this.gridViewDS);
            this.bunifuPanel1.Controls.Add(this.gridViewStatus);
            this.bunifuPanel1.Controls.Add(this.pictureBox8);
            this.bunifuPanel1.Controls.Add(this.bunifuPanel2);
            this.bunifuPanel1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bunifuPanel1.Location = new System.Drawing.Point(9, 50);
            this.bunifuPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuPanel1.Name = "bunifuPanel1";
            this.bunifuPanel1.ShowBorders = true;
            this.bunifuPanel1.Size = new System.Drawing.Size(1900, 1010);
            this.bunifuPanel1.TabIndex = 1;
            // 
            // batValue1
            // 
            this.batValue1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.batValue1.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.batValue1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.batValue1.Location = new System.Drawing.Point(1611, 93);
            this.batValue1.Name = "batValue1";
            this.batValue1.Size = new System.Drawing.Size(30, 25);
            this.batValue1.TabIndex = 40;
            this.batValue1.Text = "%";
            this.batValue1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // batteryLevel1
            // 
            this.batteryLevel1.AllowAnimations = false;
            this.batteryLevel1.Animation = 0;
            this.batteryLevel1.AnimationSpeed = 220;
            this.batteryLevel1.AnimationStep = 10;
            this.batteryLevel1.BackColor = System.Drawing.Color.Transparent;
            this.batteryLevel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("batteryLevel1.BackgroundImage")));
            this.batteryLevel1.BorderColor = System.Drawing.Color.Transparent;
            this.batteryLevel1.BorderRadius = 1;
            this.batteryLevel1.BorderThickness = 1;
            this.batteryLevel1.ForeColor = System.Drawing.Color.Transparent;
            this.batteryLevel1.Location = new System.Drawing.Point(1540, 94);
            this.batteryLevel1.Margin = new System.Windows.Forms.Padding(1);
            this.batteryLevel1.Maximum = 100;
            this.batteryLevel1.MaximumValue = 100;
            this.batteryLevel1.Minimum = 0;
            this.batteryLevel1.MinimumValue = 0;
            this.batteryLevel1.Name = "batteryLevel1";
            this.batteryLevel1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.batteryLevel1.ProgressBackColor = System.Drawing.Color.Transparent;
            this.batteryLevel1.ProgressColorLeft = System.Drawing.Color.LawnGreen;
            this.batteryLevel1.ProgressColorRight = System.Drawing.Color.LimeGreen;
            this.batteryLevel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.batteryLevel1.Size = new System.Drawing.Size(61, 23);
            this.batteryLevel1.TabIndex = 39;
            this.batteryLevel1.Value = 100;
            this.batteryLevel1.ValueByTransition = 100;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(1537, 90);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(70, 30);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 137;
            this.pictureBox6.TabStop = false;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.label17.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label17.Location = new System.Drawing.Point(1634, 94);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(25, 23);
            this.label17.TabIndex = 41;
            this.label17.Text = "%";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gridViewError
            // 
            this.gridViewError.AllowCustomTheming = false;
            this.gridViewError.AllowUserToAddRows = false;
            this.gridViewError.AllowUserToDeleteRows = false;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.Black;
            this.gridViewError.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.gridViewError.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridViewError.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.gridViewError.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gridViewError.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.gridViewError.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.Crimson;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(16)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridViewError.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.gridViewError.ColumnHeadersHeight = 40;
            this.gridViewError.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column_TimeError,
            this.Column_AGV_Error,
            this.Column_Message});
            this.gridViewError.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            this.gridViewError.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gridViewError.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.gridViewError.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.gridViewError.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.gridViewError.CurrentTheme.BackColor = System.Drawing.Color.Crimson;
            this.gridViewError.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.gridViewError.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.Crimson;
            this.gridViewError.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.gridViewError.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.gridViewError.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(16)))), ((int)(((byte)(48)))));
            this.gridViewError.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.gridViewError.CurrentTheme.Name = null;
            this.gridViewError.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            this.gridViewError.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gridViewError.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.gridViewError.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.gridViewError.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.gridViewError.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridViewError.DefaultCellStyle = dataGridViewCellStyle23;
            this.gridViewError.EnableHeadersVisualStyles = false;
            this.gridViewError.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.gridViewError.HeaderBackColor = System.Drawing.Color.Crimson;
            this.gridViewError.HeaderBgColor = System.Drawing.Color.Empty;
            this.gridViewError.HeaderForeColor = System.Drawing.Color.White;
            this.gridViewError.Location = new System.Drawing.Point(1536, 660);
            this.gridViewError.Margin = new System.Windows.Forms.Padding(2);
            this.gridViewError.Name = "gridViewError";
            this.gridViewError.ReadOnly = true;
            this.gridViewError.RowHeadersVisible = false;
            this.gridViewError.RowHeadersWidth = 362;
            this.gridViewError.RowTemplate.Height = 40;
            this.gridViewError.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridViewError.Size = new System.Drawing.Size(349, 200);
            this.gridViewError.TabIndex = 1;
            this.gridViewError.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Crimson;
            // 
            // Column_TimeError
            // 
            this.Column_TimeError.HeaderText = "Time";
            this.Column_TimeError.MinimumWidth = 6;
            this.Column_TimeError.Name = "Column_TimeError";
            this.Column_TimeError.ReadOnly = true;
            this.Column_TimeError.Visible = false;
            // 
            // Column_AGV_Error
            // 
            this.Column_AGV_Error.HeaderText = "AGV";
            this.Column_AGV_Error.MinimumWidth = 6;
            this.Column_AGV_Error.Name = "Column_AGV_Error";
            this.Column_AGV_Error.ReadOnly = true;
            this.Column_AGV_Error.Visible = false;
            // 
            // Column_Message
            // 
            this.Column_Message.HeaderText = "Message";
            this.Column_Message.MinimumWidth = 6;
            this.Column_Message.Name = "Column_Message";
            this.Column_Message.ReadOnly = true;
            this.Column_Message.Visible = false;
            // 
            // dateLabel
            // 
            this.dateLabel.AllowParentOverrides = false;
            this.dateLabel.AutoEllipsis = false;
            this.dateLabel.AutoSize = false;
            this.dateLabel.Cursor = System.Windows.Forms.Cursors.Default;
            this.dateLabel.CursorType = System.Windows.Forms.Cursors.Default;
            this.dateLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dateLabel.Location = new System.Drawing.Point(1678, 20);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dateLabel.Size = new System.Drawing.Size(206, 21);
            this.dateLabel.TabIndex = 38;
            this.dateLabel.Text = "dateLabel";
            this.dateLabel.TextAlignment = System.Drawing.ContentAlignment.MiddleRight;
            this.dateLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(1533, 640);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(144, 18);
            this.label4.TabIndex = 10;
            this.label4.Text = "AGV Error History";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(1536, 172);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 18);
            this.label3.TabIndex = 9;
            this.label3.Text = "AGV Delivery Status";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(1536, 23);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 18);
            this.label2.TabIndex = 8;
            this.label2.Text = "AGV Status";
            // 
            // gridViewDS
            // 
            this.gridViewDS.AllowCustomTheming = false;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(242)))), ((int)(((byte)(203)))));
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.Black;
            this.gridViewDS.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle24;
            this.gridViewDS.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridViewDS.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.gridViewDS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gridViewDS.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.gridViewDS.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.LimeGreen;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(164)))), ((int)(((byte)(40)))));
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridViewDS.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.gridViewDS.ColumnHeadersHeight = 40;
            this.gridViewDS.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column_Time_Deliv,
            this.Column_AGV_Delivery,
            this.Column_Delivery});
            this.gridViewDS.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(242)))), ((int)(((byte)(203)))));
            this.gridViewDS.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gridViewDS.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.gridViewDS.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(225)))), ((int)(((byte)(132)))));
            this.gridViewDS.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.gridViewDS.CurrentTheme.BackColor = System.Drawing.Color.LimeGreen;
            this.gridViewDS.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(240)))), ((int)(((byte)(193)))));
            this.gridViewDS.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.LimeGreen;
            this.gridViewDS.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.gridViewDS.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.gridViewDS.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(164)))), ((int)(((byte)(40)))));
            this.gridViewDS.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.gridViewDS.CurrentTheme.Name = null;
            this.gridViewDS.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(245)))), ((int)(((byte)(214)))));
            this.gridViewDS.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gridViewDS.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.gridViewDS.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(225)))), ((int)(((byte)(132)))));
            this.gridViewDS.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.gridViewDS.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(245)))), ((int)(((byte)(214)))));
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(225)))), ((int)(((byte)(132)))));
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridViewDS.DefaultCellStyle = dataGridViewCellStyle26;
            this.gridViewDS.EnableHeadersVisualStyles = false;
            this.gridViewDS.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(240)))), ((int)(((byte)(193)))));
            this.gridViewDS.HeaderBackColor = System.Drawing.Color.LimeGreen;
            this.gridViewDS.HeaderBgColor = System.Drawing.Color.Empty;
            this.gridViewDS.HeaderForeColor = System.Drawing.Color.White;
            this.gridViewDS.Location = new System.Drawing.Point(1536, 192);
            this.gridViewDS.Margin = new System.Windows.Forms.Padding(2);
            this.gridViewDS.Name = "gridViewDS";
            this.gridViewDS.ReadOnly = true;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridViewDS.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.gridViewDS.RowHeadersVisible = false;
            this.gridViewDS.RowHeadersWidth = 362;
            this.gridViewDS.RowTemplate.Height = 40;
            this.gridViewDS.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridViewDS.Size = new System.Drawing.Size(349, 446);
            this.gridViewDS.TabIndex = 2;
            this.gridViewDS.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.LimeGreen;
            // 
            // Column_Time_Deliv
            // 
            this.Column_Time_Deliv.HeaderText = "Time";
            this.Column_Time_Deliv.MinimumWidth = 6;
            this.Column_Time_Deliv.Name = "Column_Time_Deliv";
            this.Column_Time_Deliv.ReadOnly = true;
            this.Column_Time_Deliv.Visible = false;
            // 
            // Column_AGV_Delivery
            // 
            this.Column_AGV_Delivery.HeaderText = "AGV";
            this.Column_AGV_Delivery.MinimumWidth = 6;
            this.Column_AGV_Delivery.Name = "Column_AGV_Delivery";
            this.Column_AGV_Delivery.ReadOnly = true;
            this.Column_AGV_Delivery.Visible = false;
            // 
            // Column_Delivery
            // 
            this.Column_Delivery.HeaderText = "Delivery";
            this.Column_Delivery.MinimumWidth = 6;
            this.Column_Delivery.Name = "Column_Delivery";
            this.Column_Delivery.ReadOnly = true;
            this.Column_Delivery.Visible = false;
            // 
            // gridViewStatus
            // 
            this.gridViewStatus.AllowCustomTheming = false;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.Black;
            this.gridViewStatus.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle28;
            this.gridViewStatus.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridViewStatus.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.gridViewStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gridViewStatus.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.gridViewStatus.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridViewStatus.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.gridViewStatus.ColumnHeadersHeight = 40;
            this.gridViewStatus.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Battery});
            this.gridViewStatus.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.gridViewStatus.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gridViewStatus.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.gridViewStatus.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.gridViewStatus.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.gridViewStatus.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.gridViewStatus.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.gridViewStatus.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.gridViewStatus.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.gridViewStatus.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.gridViewStatus.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.gridViewStatus.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.gridViewStatus.CurrentTheme.Name = null;
            this.gridViewStatus.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.gridViewStatus.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gridViewStatus.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.gridViewStatus.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.gridViewStatus.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.gridViewStatus.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle30.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridViewStatus.DefaultCellStyle = dataGridViewCellStyle30;
            this.gridViewStatus.EnableHeadersVisualStyles = false;
            this.gridViewStatus.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.gridViewStatus.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.gridViewStatus.HeaderBgColor = System.Drawing.Color.Empty;
            this.gridViewStatus.HeaderForeColor = System.Drawing.Color.White;
            this.gridViewStatus.Location = new System.Drawing.Point(1536, 43);
            this.gridViewStatus.Margin = new System.Windows.Forms.Padding(2);
            this.gridViewStatus.Name = "gridViewStatus";
            this.gridViewStatus.RowHeadersVisible = false;
            this.gridViewStatus.RowHeadersWidth = 362;
            this.gridViewStatus.RowTemplate.Height = 40;
            this.gridViewStatus.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridViewStatus.Size = new System.Drawing.Size(349, 80);
            this.gridViewStatus.TabIndex = 0;
            this.gridViewStatus.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // Battery
            // 
            this.Battery.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Battery.HeaderText = "Battery";
            this.Battery.Name = "Battery";
            this.Battery.ReadOnly = true;
            this.Battery.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Battery.Width = 125;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(1536, 805);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(362, 312);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 7;
            this.pictureBox8.TabStop = false;
            // 
            // bunifuPanel2
            // 
            this.bunifuPanel2.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel2.BackgroundImage")));
            this.bunifuPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel2.BorderColor = System.Drawing.Color.Transparent;
            this.bunifuPanel2.BorderRadius = 10;
            this.bunifuPanel2.BorderThickness = 0;
            this.bunifuPanel2.Controls.Add(this.rfid25);
            this.bunifuPanel2.Controls.Add(this.rfid24);
            this.bunifuPanel2.Controls.Add(this.rfid23);
            this.bunifuPanel2.Controls.Add(this.rfid22);
            this.bunifuPanel2.Controls.Add(this.rfid21);
            this.bunifuPanel2.Controls.Add(this.rfid20);
            this.bunifuPanel2.Controls.Add(this.agvIcon);
            this.bunifuPanel2.Controls.Add(this.rfid2);
            this.bunifuPanel2.Controls.Add(this.textBox14);
            this.bunifuPanel2.Controls.Add(this.rfid11);
            this.bunifuPanel2.Controls.Add(this.rfid19);
            this.bunifuPanel2.Controls.Add(this.rfid4);
            this.bunifuPanel2.Controls.Add(this.rfid41);
            this.bunifuPanel2.Controls.Add(this.rfid39);
            this.bunifuPanel2.Controls.Add(this.rfid37);
            this.bunifuPanel2.Controls.Add(this.rfid15);
            this.bunifuPanel2.Controls.Add(this.rfid33);
            this.bunifuPanel2.Controls.Add(this.rfid32);
            this.bunifuPanel2.Controls.Add(this.rfid9);
            this.bunifuPanel2.Controls.Add(this.rfid10);
            this.bunifuPanel2.Controls.Add(this.stanbyLine1);
            this.bunifuPanel2.Controls.Add(this.rfid8);
            this.bunifuPanel2.Controls.Add(this.tbox12);
            this.bunifuPanel2.Controls.Add(this.tbox11);
            this.bunifuPanel2.Controls.Add(this.tbox10);
            this.bunifuPanel2.Controls.Add(this.tbox9);
            this.bunifuPanel2.Controls.Add(this.tbox8);
            this.bunifuPanel2.Controls.Add(this.tbox7);
            this.bunifuPanel2.Controls.Add(this.rfid42);
            this.bunifuPanel2.Controls.Add(this.rfid40);
            this.bunifuPanel2.Controls.Add(this.rfid38);
            this.bunifuPanel2.Controls.Add(this.rfid16);
            this.bunifuPanel2.Controls.Add(this.rfid34);
            this.bunifuPanel2.Controls.Add(this.rfid31);
            this.bunifuPanel2.Controls.Add(this.rfid1);
            this.bunifuPanel2.Controls.Add(this.homeBox);
            this.bunifuPanel2.Controls.Add(this.textBox1);
            this.bunifuPanel2.Controls.Add(this.wipOut2);
            this.bunifuPanel2.Controls.Add(this.wipOut1);
            this.bunifuPanel2.Controls.Add(this.wipIn6);
            this.bunifuPanel2.Controls.Add(this.wipIn5);
            this.bunifuPanel2.Controls.Add(this.wipIn4);
            this.bunifuPanel2.Controls.Add(this.wipIn3);
            this.bunifuPanel2.Controls.Add(this.wipIn2);
            this.bunifuPanel2.Controls.Add(this.wipIn1);
            this.bunifuPanel2.Controls.Add(this.pictureBox15);
            this.bunifuPanel2.Controls.Add(this.tbox1);
            this.bunifuPanel2.Controls.Add(this.tbox2);
            this.bunifuPanel2.Controls.Add(this.tbox3);
            this.bunifuPanel2.Controls.Add(this.tbox4);
            this.bunifuPanel2.Controls.Add(this.tbox5);
            this.bunifuPanel2.Controls.Add(this.tbox6);
            this.bunifuPanel2.Controls.Add(this.stopLine3);
            this.bunifuPanel2.Controls.Add(this.stopLine2);
            this.bunifuPanel2.Controls.Add(this.goLine2);
            this.bunifuPanel2.Controls.Add(this.pictureBox21);
            this.bunifuPanel2.Controls.Add(this.pictureBox20);
            this.bunifuPanel2.Controls.Add(this.SMD07);
            this.bunifuPanel2.Controls.Add(this.SMD01);
            this.bunifuPanel2.Controls.Add(this.TNP02);
            this.bunifuPanel2.Controls.Add(this.TNP01);
            this.bunifuPanel2.Controls.Add(this.TNP03);
            this.bunifuPanel2.Controls.Add(this.SMD09);
            this.bunifuPanel2.Controls.Add(this.SMD08);
            this.bunifuPanel2.Controls.Add(this.SMD06);
            this.bunifuPanel2.Controls.Add(this.SMD05);
            this.bunifuPanel2.Controls.Add(this.SMD04);
            this.bunifuPanel2.Controls.Add(this.SMD02);
            this.bunifuPanel2.Controls.Add(this.pictureBox16);
            this.bunifuPanel2.Controls.Add(this.standbyLine2);
            this.bunifuPanel2.Controls.Add(this.standbyLine3);
            this.bunifuPanel2.Controls.Add(this.standby5);
            this.bunifuPanel2.Controls.Add(this.SMD03);
            this.bunifuPanel2.Controls.Add(this.standby3);
            this.bunifuPanel2.Controls.Add(this.standby2);
            this.bunifuPanel2.Controls.Add(this.pictureBox4);
            this.bunifuPanel2.Controls.Add(this.standby6);
            this.bunifuPanel2.Controls.Add(this.send6);
            this.bunifuPanel2.Controls.Add(this.send5);
            this.bunifuPanel2.Controls.Add(this.send3);
            this.bunifuPanel2.Controls.Add(this.send2);
            this.bunifuPanel2.Controls.Add(this.standby1);
            this.bunifuPanel2.Controls.Add(this.send1);
            this.bunifuPanel2.Controls.Add(this.goLine1);
            this.bunifuPanel2.Controls.Add(this.idleSmd1);
            this.bunifuPanel2.Controls.Add(this.standbyWip);
            this.bunifuPanel2.Controls.Add(this.pictureBox2);
            this.bunifuPanel2.Controls.Add(this.panel1);
            this.bunifuPanel2.Controls.Add(this.pictureBox1);
            this.bunifuPanel2.Controls.Add(this.pictureBox11);
            this.bunifuPanel2.Controls.Add(this.pictureBox10);
            this.bunifuPanel2.Controls.Add(this.pictureBox9);
            this.bunifuPanel2.Controls.Add(this.pictureBox5);
            this.bunifuPanel2.Controls.Add(this.pictureBox12);
            this.bunifuPanel2.Controls.Add(this.standby4);
            this.bunifuPanel2.Controls.Add(this.send4);
            this.bunifuPanel2.Controls.Add(this.pictureBox3);
            this.bunifuPanel2.Controls.Add(this.stopLine1);
            this.bunifuPanel2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bunifuPanel2.Location = new System.Drawing.Point(16, 20);
            this.bunifuPanel2.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuPanel2.Name = "bunifuPanel2";
            this.bunifuPanel2.ShowBorders = true;
            this.bunifuPanel2.Size = new System.Drawing.Size(1513, 980);
            this.bunifuPanel2.TabIndex = 5;
            // 
            // agvIcon
            // 
            this.agvIcon.BackColor = System.Drawing.Color.Transparent;
            this.agvIcon.Image = global::SampleUI_SamsungAGV.Properties.Resources.AGVC;
            this.agvIcon.Location = new System.Drawing.Point(1041, 634);
            this.agvIcon.Margin = new System.Windows.Forms.Padding(1);
            this.agvIcon.Name = "agvIcon";
            this.agvIcon.Size = new System.Drawing.Size(51, 64);
            this.agvIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.agvIcon.TabIndex = 78;
            this.agvIcon.TabStop = false;
            // 
            // rfid2
            // 
            this.rfid2.Location = new System.Drawing.Point(1048, 640);
            this.rfid2.Name = "rfid2";
            this.rfid2.Size = new System.Drawing.Size(31, 20);
            this.rfid2.TabIndex = 180;
            this.rfid2.Text = "R2";
            this.rfid2.Visible = false;
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.Color.PapayaWhip;
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox14.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox14.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(1192, 940);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(35, 17);
            this.textBox14.TabIndex = 193;
            this.textBox14.Text = "LIFT";
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rfid11
            // 
            this.rfid11.Location = new System.Drawing.Point(950, 599);
            this.rfid11.Name = "rfid11";
            this.rfid11.Size = new System.Drawing.Size(25, 20);
            this.rfid11.TabIndex = 192;
            this.rfid11.Text = "R11";
            this.rfid11.Visible = false;
            // 
            // rfid19
            // 
            this.rfid19.Location = new System.Drawing.Point(1048, 864);
            this.rfid19.Name = "rfid19";
            this.rfid19.Size = new System.Drawing.Size(35, 20);
            this.rfid19.TabIndex = 191;
            this.rfid19.Text = "R19";
            this.rfid19.Visible = false;
            // 
            // rfid4
            // 
            this.rfid4.Location = new System.Drawing.Point(1048, 655);
            this.rfid4.Name = "rfid4";
            this.rfid4.Size = new System.Drawing.Size(25, 20);
            this.rfid4.TabIndex = 190;
            this.rfid4.Text = "R4";
            this.rfid4.Visible = false;
            // 
            // rfid41
            // 
            this.rfid41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfid41.Location = new System.Drawing.Point(708, 148);
            this.rfid41.Name = "rfid41";
            this.rfid41.Size = new System.Drawing.Size(45, 20);
            this.rfid41.TabIndex = 189;
            this.rfid41.Text = "R41";
            this.rfid41.Visible = false;
            // 
            // rfid39
            // 
            this.rfid39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfid39.Location = new System.Drawing.Point(708, 243);
            this.rfid39.Name = "rfid39";
            this.rfid39.Size = new System.Drawing.Size(45, 20);
            this.rfid39.TabIndex = 188;
            this.rfid39.Text = "R39";
            this.rfid39.Visible = false;
            // 
            // rfid37
            // 
            this.rfid37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfid37.Location = new System.Drawing.Point(708, 341);
            this.rfid37.Name = "rfid37";
            this.rfid37.Size = new System.Drawing.Size(45, 20);
            this.rfid37.TabIndex = 187;
            this.rfid37.Text = "R37";
            this.rfid37.Visible = false;
            // 
            // rfid15
            // 
            this.rfid15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfid15.Location = new System.Drawing.Point(708, 442);
            this.rfid15.Name = "rfid15";
            this.rfid15.Size = new System.Drawing.Size(45, 20);
            this.rfid15.TabIndex = 186;
            this.rfid15.Text = "R15";
            this.rfid15.Visible = false;
            // 
            // rfid33
            // 
            this.rfid33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfid33.Location = new System.Drawing.Point(708, 540);
            this.rfid33.Name = "rfid33";
            this.rfid33.Size = new System.Drawing.Size(45, 20);
            this.rfid33.TabIndex = 185;
            this.rfid33.Text = "R33";
            this.rfid33.Visible = false;
            // 
            // rfid32
            // 
            this.rfid32.Location = new System.Drawing.Point(708, 598);
            this.rfid32.Name = "rfid32";
            this.rfid32.Size = new System.Drawing.Size(45, 20);
            this.rfid32.TabIndex = 184;
            this.rfid32.Text = "R32";
            this.rfid32.Visible = false;
            // 
            // rfid9
            // 
            this.rfid9.Location = new System.Drawing.Point(1048, 915);
            this.rfid9.Name = "rfid9";
            this.rfid9.Size = new System.Drawing.Size(57, 20);
            this.rfid9.TabIndex = 178;
            this.rfid9.Text = "R9";
            this.rfid9.Visible = false;
            // 
            // rfid10
            // 
            this.rfid10.Location = new System.Drawing.Point(1048, 915);
            this.rfid10.Name = "rfid10";
            this.rfid10.Size = new System.Drawing.Size(35, 20);
            this.rfid10.TabIndex = 183;
            this.rfid10.Text = "R10";
            this.rfid10.Visible = false;
            // 
            // rfid25
            // 
            this.rfid25.Location = new System.Drawing.Point(1048, 817);
            this.rfid25.Name = "rfid25";
            this.rfid25.Size = new System.Drawing.Size(35, 20);
            this.rfid25.TabIndex = 161;
            this.rfid25.Text = "R25";
            this.rfid25.Visible = false;
            // 
            // rfid24
            // 
            this.rfid24.Location = new System.Drawing.Point(1048, 790);
            this.rfid24.Name = "rfid24";
            this.rfid24.Size = new System.Drawing.Size(35, 20);
            this.rfid24.TabIndex = 160;
            this.rfid24.Text = "R24";
            this.rfid24.Visible = false;
            // 
            // rfid23
            // 
            this.rfid23.Location = new System.Drawing.Point(1048, 763);
            this.rfid23.Name = "rfid23";
            this.rfid23.Size = new System.Drawing.Size(35, 20);
            this.rfid23.TabIndex = 159;
            this.rfid23.Text = "R23";
            this.rfid23.Visible = false;
            // 
            // rfid22
            // 
            this.rfid22.Location = new System.Drawing.Point(1048, 736);
            this.rfid22.Name = "rfid22";
            this.rfid22.Size = new System.Drawing.Size(35, 20);
            this.rfid22.TabIndex = 158;
            this.rfid22.Text = "R22";
            this.rfid22.Visible = false;
            // 
            // rfid21
            // 
            this.rfid21.Location = new System.Drawing.Point(1048, 709);
            this.rfid21.Name = "rfid21";
            this.rfid21.Size = new System.Drawing.Size(35, 20);
            this.rfid21.TabIndex = 157;
            this.rfid21.Text = "R21";
            this.rfid21.Visible = false;
            // 
            // rfid20
            // 
            this.rfid20.Location = new System.Drawing.Point(1048, 682);
            this.rfid20.Name = "rfid20";
            this.rfid20.Size = new System.Drawing.Size(35, 20);
            this.rfid20.TabIndex = 156;
            this.rfid20.Text = "R20";
            this.rfid20.Visible = false;
            // 
            // stanbyLine1
            // 
            this.stanbyLine1.BackColor = System.Drawing.Color.Black;
            this.stanbyLine1.Location = new System.Drawing.Point(1074, 630);
            this.stanbyLine1.Margin = new System.Windows.Forms.Padding(2);
            this.stanbyLine1.Name = "stanbyLine1";
            this.stanbyLine1.Size = new System.Drawing.Size(4, 350);
            this.stanbyLine1.TabIndex = 111;
            this.stanbyLine1.TabStop = false;
            // 
            // rfid8
            // 
            this.rfid8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfid8.Location = new System.Drawing.Point(708, 36);
            this.rfid8.Name = "rfid8";
            this.rfid8.Size = new System.Drawing.Size(45, 20);
            this.rfid8.TabIndex = 177;
            this.rfid8.Text = "R8";
            this.rfid8.Visible = false;
            // 
            // tbox12
            // 
            this.tbox12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox12.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox12.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox12.Location = new System.Drawing.Point(1326, 53);
            this.tbox12.Name = "tbox12";
            this.tbox12.Size = new System.Drawing.Size(55, 17);
            this.tbox12.TabIndex = 170;
            this.tbox12.Text = "TNP 02";
            this.tbox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbox11
            // 
            this.tbox11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox11.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox11.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox11.Location = new System.Drawing.Point(1326, 150);
            this.tbox11.Name = "tbox11";
            this.tbox11.Size = new System.Drawing.Size(55, 17);
            this.tbox11.TabIndex = 169;
            this.tbox11.Text = "TNP 01";
            this.tbox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbox10
            // 
            this.tbox10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox10.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox10.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox10.Location = new System.Drawing.Point(1326, 247);
            this.tbox10.Name = "tbox10";
            this.tbox10.Size = new System.Drawing.Size(55, 17);
            this.tbox10.TabIndex = 168;
            this.tbox10.Text = "TNP 03";
            this.tbox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbox9
            // 
            this.tbox9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox9.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox9.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox9.Location = new System.Drawing.Point(1326, 347);
            this.tbox9.Name = "tbox9";
            this.tbox9.Size = new System.Drawing.Size(55, 17);
            this.tbox9.TabIndex = 167;
            this.tbox9.Text = "SMD 09";
            this.tbox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbox8
            // 
            this.tbox8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox8.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox8.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox8.Location = new System.Drawing.Point(1326, 443);
            this.tbox8.Name = "tbox8";
            this.tbox8.Size = new System.Drawing.Size(55, 17);
            this.tbox8.TabIndex = 166;
            this.tbox8.Text = "SMD 08";
            this.tbox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbox7
            // 
            this.tbox7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox7.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox7.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox7.Location = new System.Drawing.Point(1326, 546);
            this.tbox7.Name = "tbox7";
            this.tbox7.Size = new System.Drawing.Size(55, 17);
            this.tbox7.TabIndex = 165;
            this.tbox7.Text = "SMD 07";
            this.tbox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rfid42
            // 
            this.rfid42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfid42.Location = new System.Drawing.Point(708, 129);
            this.rfid42.Name = "rfid42";
            this.rfid42.Size = new System.Drawing.Size(45, 20);
            this.rfid42.TabIndex = 155;
            this.rfid42.Text = "R42";
            this.rfid42.Visible = false;
            // 
            // rfid40
            // 
            this.rfid40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfid40.Location = new System.Drawing.Point(708, 226);
            this.rfid40.Name = "rfid40";
            this.rfid40.Size = new System.Drawing.Size(45, 20);
            this.rfid40.TabIndex = 154;
            this.rfid40.Text = "R40";
            this.rfid40.Visible = false;
            // 
            // rfid38
            // 
            this.rfid38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfid38.Location = new System.Drawing.Point(708, 325);
            this.rfid38.Name = "rfid38";
            this.rfid38.Size = new System.Drawing.Size(45, 20);
            this.rfid38.TabIndex = 153;
            this.rfid38.Text = "R38";
            this.rfid38.Visible = false;
            // 
            // rfid16
            // 
            this.rfid16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfid16.Location = new System.Drawing.Point(708, 424);
            this.rfid16.Name = "rfid16";
            this.rfid16.Size = new System.Drawing.Size(45, 20);
            this.rfid16.TabIndex = 152;
            this.rfid16.Text = "R16";
            this.rfid16.Visible = false;
            // 
            // rfid34
            // 
            this.rfid34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfid34.Location = new System.Drawing.Point(708, 522);
            this.rfid34.Name = "rfid34";
            this.rfid34.Size = new System.Drawing.Size(45, 20);
            this.rfid34.TabIndex = 151;
            this.rfid34.Text = "R34";
            this.rfid34.Visible = false;
            // 
            // rfid31
            // 
            this.rfid31.Location = new System.Drawing.Point(759, 599);
            this.rfid31.Name = "rfid31";
            this.rfid31.Size = new System.Drawing.Size(32, 20);
            this.rfid31.TabIndex = 150;
            this.rfid31.Text = "R31";
            this.rfid31.Visible = false;
            // 
            // rfid1
            // 
            this.rfid1.Location = new System.Drawing.Point(992, 599);
            this.rfid1.Name = "rfid1";
            this.rfid1.Size = new System.Drawing.Size(25, 20);
            this.rfid1.TabIndex = 149;
            this.rfid1.Text = "R1";
            this.rfid1.Visible = false;
            // 
            // homeBox
            // 
            this.homeBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(255)))), ((int)(((byte)(204)))));
            this.homeBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.homeBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.homeBox.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeBox.Location = new System.Drawing.Point(1135, 658);
            this.homeBox.Name = "homeBox";
            this.homeBox.Size = new System.Drawing.Size(75, 17);
            this.homeBox.TabIndex = 146;
            this.homeBox.Text = "HOME BASE";
            this.homeBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Lime;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Tai Le", 7.25F);
            this.textBox1.Location = new System.Drawing.Point(1133, 884);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(53, 13);
            this.textBox1.TabIndex = 145;
            this.textBox1.Text = "OPERATOR";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wipOut2
            // 
            this.wipOut2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.wipOut2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.wipOut2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.wipOut2.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wipOut2.Location = new System.Drawing.Point(1127, 952);
            this.wipOut2.Name = "wipOut2";
            this.wipOut2.Size = new System.Drawing.Size(55, 17);
            this.wipOut2.TabIndex = 144;
            this.wipOut2.Text = "OUT 2";
            this.wipOut2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wipOut1
            // 
            this.wipOut1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.wipOut1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.wipOut1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.wipOut1.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wipOut1.Location = new System.Drawing.Point(1127, 926);
            this.wipOut1.Name = "wipOut1";
            this.wipOut1.Size = new System.Drawing.Size(55, 17);
            this.wipOut1.TabIndex = 143;
            this.wipOut1.Text = "OUT 1";
            this.wipOut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wipIn6
            // 
            this.wipIn6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.wipIn6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.wipIn6.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.wipIn6.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wipIn6.Location = new System.Drawing.Point(1145, 840);
            this.wipIn6.Name = "wipIn6";
            this.wipIn6.Size = new System.Drawing.Size(55, 17);
            this.wipIn6.TabIndex = 142;
            this.wipIn6.Text = "IN 6";
            this.wipIn6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wipIn5
            // 
            this.wipIn5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.wipIn5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.wipIn5.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.wipIn5.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wipIn5.Location = new System.Drawing.Point(1145, 812);
            this.wipIn5.Name = "wipIn5";
            this.wipIn5.Size = new System.Drawing.Size(55, 17);
            this.wipIn5.TabIndex = 141;
            this.wipIn5.Text = "IN 5";
            this.wipIn5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wipIn4
            // 
            this.wipIn4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.wipIn4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.wipIn4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.wipIn4.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wipIn4.Location = new System.Drawing.Point(1145, 784);
            this.wipIn4.Name = "wipIn4";
            this.wipIn4.Size = new System.Drawing.Size(55, 17);
            this.wipIn4.TabIndex = 140;
            this.wipIn4.Text = "IN 4";
            this.wipIn4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wipIn3
            // 
            this.wipIn3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.wipIn3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.wipIn3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.wipIn3.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wipIn3.Location = new System.Drawing.Point(1145, 756);
            this.wipIn3.Name = "wipIn3";
            this.wipIn3.Size = new System.Drawing.Size(55, 17);
            this.wipIn3.TabIndex = 139;
            this.wipIn3.Text = "IN 3";
            this.wipIn3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wipIn2
            // 
            this.wipIn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.wipIn2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.wipIn2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.wipIn2.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wipIn2.Location = new System.Drawing.Point(1145, 728);
            this.wipIn2.Name = "wipIn2";
            this.wipIn2.Size = new System.Drawing.Size(55, 17);
            this.wipIn2.TabIndex = 138;
            this.wipIn2.Text = "IN 2";
            this.wipIn2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wipIn1
            // 
            this.wipIn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.wipIn1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.wipIn1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.wipIn1.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wipIn1.Location = new System.Drawing.Point(1145, 700);
            this.wipIn1.Name = "wipIn1";
            this.wipIn1.Size = new System.Drawing.Size(55, 17);
            this.wipIn1.TabIndex = 137;
            this.wipIn1.Text = "IN 1";
            this.wipIn1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(1111, 637);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(127, 343);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 83;
            this.pictureBox15.TabStop = false;
            // 
            // tbox1
            // 
            this.tbox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox1.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox1.Location = new System.Drawing.Point(583, 546);
            this.tbox1.Name = "tbox1";
            this.tbox1.Size = new System.Drawing.Size(55, 17);
            this.tbox1.TabIndex = 122;
            this.tbox1.Text = "SMD 01";
            this.tbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbox2
            // 
            this.tbox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox2.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox2.Location = new System.Drawing.Point(582, 444);
            this.tbox2.Name = "tbox2";
            this.tbox2.Size = new System.Drawing.Size(55, 17);
            this.tbox2.TabIndex = 121;
            this.tbox2.Text = "SMD 02";
            this.tbox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbox3
            // 
            this.tbox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox3.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox3.Location = new System.Drawing.Point(582, 347);
            this.tbox3.Name = "tbox3";
            this.tbox3.Size = new System.Drawing.Size(55, 17);
            this.tbox3.TabIndex = 120;
            this.tbox3.Text = "SMD 03";
            this.tbox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbox4
            // 
            this.tbox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox4.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox4.Location = new System.Drawing.Point(582, 248);
            this.tbox4.Name = "tbox4";
            this.tbox4.Size = new System.Drawing.Size(55, 17);
            this.tbox4.TabIndex = 119;
            this.tbox4.Text = "SMD 04";
            this.tbox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbox5
            // 
            this.tbox5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox5.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox5.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox5.Location = new System.Drawing.Point(581, 152);
            this.tbox5.Name = "tbox5";
            this.tbox5.Size = new System.Drawing.Size(55, 17);
            this.tbox5.TabIndex = 118;
            this.tbox5.Text = "SMD 05";
            this.tbox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbox6
            // 
            this.tbox6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox6.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbox6.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox6.Location = new System.Drawing.Point(581, 55);
            this.tbox6.Name = "tbox6";
            this.tbox6.Size = new System.Drawing.Size(55, 17);
            this.tbox6.TabIndex = 117;
            this.tbox6.Text = "SMD 06";
            this.tbox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // stopLine3
            // 
            this.stopLine3.BackColor = System.Drawing.Color.Black;
            this.stopLine3.Location = new System.Drawing.Point(728, 551);
            this.stopLine3.Margin = new System.Windows.Forms.Padding(2);
            this.stopLine3.Name = "stopLine3";
            this.stopLine3.Size = new System.Drawing.Size(4, 80);
            this.stopLine3.TabIndex = 115;
            this.stopLine3.TabStop = false;
            // 
            // stopLine2
            // 
            this.stopLine2.BackColor = System.Drawing.Color.Black;
            this.stopLine2.Location = new System.Drawing.Point(728, 630);
            this.stopLine2.Margin = new System.Windows.Forms.Padding(2);
            this.stopLine2.Name = "stopLine2";
            this.stopLine2.Size = new System.Drawing.Size(338, 4);
            this.stopLine2.TabIndex = 113;
            this.stopLine2.TabStop = false;
            // 
            // goLine2
            // 
            this.goLine2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.goLine2.Location = new System.Drawing.Point(728, 630);
            this.goLine2.Margin = new System.Windows.Forms.Padding(2);
            this.goLine2.Name = "goLine2";
            this.goLine2.Size = new System.Drawing.Size(338, 4);
            this.goLine2.TabIndex = 112;
            this.goLine2.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.Color.Black;
            this.pictureBox21.Location = new System.Drawing.Point(1074, 680);
            this.pictureBox21.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(70, 4);
            this.pictureBox21.TabIndex = 81;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.Black;
            this.pictureBox20.Location = new System.Drawing.Point(1074, 650);
            this.pictureBox20.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(70, 4);
            this.pictureBox20.TabIndex = 84;
            this.pictureBox20.TabStop = false;
            // 
            // SMD07
            // 
            this.SMD07.BackColor = System.Drawing.Color.Transparent;
            this.SMD07.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SMD07.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.SMD07.Location = new System.Drawing.Point(786, 516);
            this.SMD07.Margin = new System.Windows.Forms.Padding(2);
            this.SMD07.Name = "SMD07";
            this.SMD07.Size = new System.Drawing.Size(650, 69);
            this.SMD07.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SMD07.TabIndex = 75;
            this.SMD07.TabStop = false;
            // 
            // SMD01
            // 
            this.SMD01.BackColor = System.Drawing.Color.Transparent;
            this.SMD01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SMD01.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.SMD01.Location = new System.Drawing.Point(41, 516);
            this.SMD01.Margin = new System.Windows.Forms.Padding(2);
            this.SMD01.Name = "SMD01";
            this.SMD01.Size = new System.Drawing.Size(650, 69);
            this.SMD01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SMD01.TabIndex = 74;
            this.SMD01.TabStop = false;
            // 
            // TNP02
            // 
            this.TNP02.BackColor = System.Drawing.Color.Transparent;
            this.TNP02.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TNP02.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.TNP02.Location = new System.Drawing.Point(786, 26);
            this.TNP02.Margin = new System.Windows.Forms.Padding(2);
            this.TNP02.Name = "TNP02";
            this.TNP02.Size = new System.Drawing.Size(650, 69);
            this.TNP02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TNP02.TabIndex = 73;
            this.TNP02.TabStop = false;
            // 
            // TNP01
            // 
            this.TNP01.BackColor = System.Drawing.Color.Transparent;
            this.TNP01.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TNP01.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.TNP01.Location = new System.Drawing.Point(786, 123);
            this.TNP01.Margin = new System.Windows.Forms.Padding(2);
            this.TNP01.Name = "TNP01";
            this.TNP01.Size = new System.Drawing.Size(650, 69);
            this.TNP01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TNP01.TabIndex = 72;
            this.TNP01.TabStop = false;
            // 
            // TNP03
            // 
            this.TNP03.BackColor = System.Drawing.Color.Transparent;
            this.TNP03.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TNP03.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.TNP03.Location = new System.Drawing.Point(786, 219);
            this.TNP03.Margin = new System.Windows.Forms.Padding(2);
            this.TNP03.Name = "TNP03";
            this.TNP03.Size = new System.Drawing.Size(650, 69);
            this.TNP03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TNP03.TabIndex = 71;
            this.TNP03.TabStop = false;
            // 
            // SMD09
            // 
            this.SMD09.BackColor = System.Drawing.Color.Transparent;
            this.SMD09.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SMD09.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.SMD09.Location = new System.Drawing.Point(786, 318);
            this.SMD09.Margin = new System.Windows.Forms.Padding(2);
            this.SMD09.Name = "SMD09";
            this.SMD09.Size = new System.Drawing.Size(650, 69);
            this.SMD09.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SMD09.TabIndex = 70;
            this.SMD09.TabStop = false;
            // 
            // SMD08
            // 
            this.SMD08.BackColor = System.Drawing.Color.Transparent;
            this.SMD08.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SMD08.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.SMD08.Location = new System.Drawing.Point(786, 415);
            this.SMD08.Margin = new System.Windows.Forms.Padding(2);
            this.SMD08.Name = "SMD08";
            this.SMD08.Size = new System.Drawing.Size(650, 69);
            this.SMD08.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SMD08.TabIndex = 69;
            this.SMD08.TabStop = false;
            // 
            // SMD06
            // 
            this.SMD06.BackColor = System.Drawing.Color.Transparent;
            this.SMD06.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SMD06.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.SMD06.Location = new System.Drawing.Point(41, 26);
            this.SMD06.Margin = new System.Windows.Forms.Padding(2);
            this.SMD06.Name = "SMD06";
            this.SMD06.Size = new System.Drawing.Size(650, 69);
            this.SMD06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SMD06.TabIndex = 68;
            this.SMD06.TabStop = false;
            // 
            // SMD05
            // 
            this.SMD05.BackColor = System.Drawing.Color.Transparent;
            this.SMD05.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SMD05.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.SMD05.Location = new System.Drawing.Point(41, 123);
            this.SMD05.Margin = new System.Windows.Forms.Padding(2);
            this.SMD05.Name = "SMD05";
            this.SMD05.Size = new System.Drawing.Size(650, 69);
            this.SMD05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SMD05.TabIndex = 67;
            this.SMD05.TabStop = false;
            // 
            // SMD04
            // 
            this.SMD04.BackColor = System.Drawing.Color.Transparent;
            this.SMD04.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SMD04.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.SMD04.Location = new System.Drawing.Point(41, 219);
            this.SMD04.Margin = new System.Windows.Forms.Padding(2);
            this.SMD04.Name = "SMD04";
            this.SMD04.Size = new System.Drawing.Size(650, 69);
            this.SMD04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SMD04.TabIndex = 66;
            this.SMD04.TabStop = false;
            // 
            // SMD02
            // 
            this.SMD02.BackColor = System.Drawing.Color.Transparent;
            this.SMD02.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SMD02.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.SMD02.Location = new System.Drawing.Point(41, 415);
            this.SMD02.Margin = new System.Windows.Forms.Padding(2);
            this.SMD02.Name = "SMD02";
            this.SMD02.Size = new System.Drawing.Size(650, 69);
            this.SMD02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SMD02.TabIndex = 58;
            this.SMD02.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.Black;
            this.pictureBox16.Location = new System.Drawing.Point(1470, 53);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(4, 580);
            this.pictureBox16.TabIndex = 40;
            this.pictureBox16.TabStop = false;
            // 
            // standbyLine2
            // 
            this.standbyLine2.BackColor = System.Drawing.Color.Black;
            this.standbyLine2.Location = new System.Drawing.Point(728, 630);
            this.standbyLine2.Margin = new System.Windows.Forms.Padding(2);
            this.standbyLine2.Name = "standbyLine2";
            this.standbyLine2.Size = new System.Drawing.Size(744, 4);
            this.standbyLine2.TabIndex = 0;
            this.standbyLine2.TabStop = false;
            // 
            // standbyLine3
            // 
            this.standbyLine3.BackColor = System.Drawing.Color.Black;
            this.standbyLine3.Location = new System.Drawing.Point(728, 48);
            this.standbyLine3.Margin = new System.Windows.Forms.Padding(2);
            this.standbyLine3.Name = "standbyLine3";
            this.standbyLine3.Size = new System.Drawing.Size(4, 580);
            this.standbyLine3.TabIndex = 16;
            this.standbyLine3.TabStop = false;
            // 
            // standby5
            // 
            this.standby5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.standby5.Location = new System.Drawing.Point(31, 113);
            this.standby5.Name = "standby5";
            this.standby5.Size = new System.Drawing.Size(670, 89);
            this.standby5.TabIndex = 100;
            this.standby5.TabStop = false;
            // 
            // SMD03
            // 
            this.SMD03.BackColor = System.Drawing.Color.Transparent;
            this.SMD03.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SMD03.Image = global::SampleUI_SamsungAGV.Properties.Resources.SAMSUNG_drawio__1_;
            this.SMD03.Location = new System.Drawing.Point(41, 318);
            this.SMD03.Margin = new System.Windows.Forms.Padding(2);
            this.SMD03.Name = "SMD03";
            this.SMD03.Size = new System.Drawing.Size(650, 69);
            this.SMD03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SMD03.TabIndex = 65;
            this.SMD03.TabStop = false;
            // 
            // standby3
            // 
            this.standby3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.standby3.Location = new System.Drawing.Point(31, 308);
            this.standby3.Name = "standby3";
            this.standby3.Size = new System.Drawing.Size(670, 89);
            this.standby3.TabIndex = 102;
            this.standby3.TabStop = false;
            // 
            // standby2
            // 
            this.standby2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.standby2.Location = new System.Drawing.Point(31, 407);
            this.standby2.Name = "standby2";
            this.standby2.Size = new System.Drawing.Size(670, 89);
            this.standby2.TabIndex = 98;
            this.standby2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.pictureBox4.Location = new System.Drawing.Point(31, 407);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(670, 89);
            this.pictureBox4.TabIndex = 97;
            this.pictureBox4.TabStop = false;
            // 
            // standby6
            // 
            this.standby6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.standby6.Location = new System.Drawing.Point(31, 16);
            this.standby6.Name = "standby6";
            this.standby6.Size = new System.Drawing.Size(670, 89);
            this.standby6.TabIndex = 99;
            this.standby6.TabStop = false;
            // 
            // send6
            // 
            this.send6.Location = new System.Drawing.Point(31, 16);
            this.send6.Name = "send6";
            this.send6.Size = new System.Drawing.Size(670, 89);
            this.send6.TabIndex = 103;
            this.send6.TabStop = false;
            // 
            // send5
            // 
            this.send5.Location = new System.Drawing.Point(31, 113);
            this.send5.Name = "send5";
            this.send5.Size = new System.Drawing.Size(670, 89);
            this.send5.TabIndex = 104;
            this.send5.TabStop = false;
            // 
            // send3
            // 
            this.send3.Location = new System.Drawing.Point(31, 308);
            this.send3.Name = "send3";
            this.send3.Size = new System.Drawing.Size(670, 89);
            this.send3.TabIndex = 106;
            this.send3.TabStop = false;
            // 
            // send2
            // 
            this.send2.Location = new System.Drawing.Point(31, 407);
            this.send2.Name = "send2";
            this.send2.Size = new System.Drawing.Size(670, 89);
            this.send2.TabIndex = 107;
            this.send2.TabStop = false;
            // 
            // standby1
            // 
            this.standby1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.standby1.Location = new System.Drawing.Point(31, 506);
            this.standby1.Name = "standby1";
            this.standby1.Size = new System.Drawing.Size(670, 89);
            this.standby1.TabIndex = 96;
            this.standby1.TabStop = false;
            // 
            // send1
            // 
            this.send1.Location = new System.Drawing.Point(31, 506);
            this.send1.Name = "send1";
            this.send1.Size = new System.Drawing.Size(670, 89);
            this.send1.TabIndex = 95;
            this.send1.TabStop = false;
            // 
            // goLine1
            // 
            this.goLine1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.goLine1.Location = new System.Drawing.Point(1074, 630);
            this.goLine1.Margin = new System.Windows.Forms.Padding(2);
            this.goLine1.Name = "goLine1";
            this.goLine1.Size = new System.Drawing.Size(4, 100);
            this.goLine1.TabIndex = 110;
            this.goLine1.TabStop = false;
            // 
            // idleSmd1
            // 
            this.idleSmd1.BackColor = System.Drawing.Color.Yellow;
            this.idleSmd1.Location = new System.Drawing.Point(31, 506);
            this.idleSmd1.Name = "idleSmd1";
            this.idleSmd1.Size = new System.Drawing.Size(670, 89);
            this.idleSmd1.TabIndex = 116;
            this.idleSmd1.TabStop = false;
            // 
            // standbyWip
            // 
            this.standbyWip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.standbyWip.Location = new System.Drawing.Point(1096, 638);
            this.standbyWip.Name = "standbyWip";
            this.standbyWip.Size = new System.Drawing.Size(142, 341);
            this.standbyWip.TabIndex = 108;
            this.standbyWip.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.pictureBox2.Location = new System.Drawing.Point(1096, 638);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(142, 341);
            this.pictureBox2.TabIndex = 109;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.rfid5);
            this.panel1.Controls.Add(this.agvLabel2);
            this.panel1.Controls.Add(this.agvLabel1);
            this.panel1.Controls.Add(this.agvHome2);
            this.panel1.Controls.Add(this.agvHome1);
            this.panel1.Controls.Add(this.textBox13);
            this.panel1.Controls.Add(this.textBox12);
            this.panel1.Controls.Add(this.textBox11);
            this.panel1.Controls.Add(this.wipFull2);
            this.panel1.Controls.Add(this.wipFull1);
            this.panel1.Controls.Add(this.textBox10);
            this.panel1.Controls.Add(this.textBox9);
            this.panel1.Controls.Add(this.textBox8);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.wip1);
            this.panel1.Controls.Add(this.labelPosition);
            this.panel1.Controls.Add(this.wip2);
            this.panel1.Controls.Add(this.wip3);
            this.panel1.Controls.Add(this.wip4);
            this.panel1.Controls.Add(this.wip5);
            this.panel1.Controls.Add(this.wip6);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.pictureBox25);
            this.panel1.Location = new System.Drawing.Point(13, 735);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1013, 245);
            this.panel1.TabIndex = 164;
            // 
            // rfid5
            // 
            this.rfid5.Location = new System.Drawing.Point(772, 74);
            this.rfid5.Name = "rfid5";
            this.rfid5.Size = new System.Drawing.Size(35, 20);
            this.rfid5.TabIndex = 182;
            this.rfid5.Text = "R5";
            this.rfid5.Visible = false;
            // 
            // agvLabel2
            // 
            this.agvLabel2.AutoSize = true;
            this.agvLabel2.BackColor = System.Drawing.Color.LightGray;
            this.agvLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.agvLabel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.agvLabel2.Location = new System.Drawing.Point(839, 100);
            this.agvLabel2.Name = "agvLabel2";
            this.agvLabel2.Size = new System.Drawing.Size(19, 20);
            this.agvLabel2.TabIndex = 180;
            this.agvLabel2.Text = "2";
            this.agvLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.agvLabel2.Visible = false;
            // 
            // agvLabel1
            // 
            this.agvLabel1.AutoSize = true;
            this.agvLabel1.BackColor = System.Drawing.Color.LightGray;
            this.agvLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.agvLabel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.agvLabel1.Location = new System.Drawing.Point(787, 100);
            this.agvLabel1.Name = "agvLabel1";
            this.agvLabel1.Size = new System.Drawing.Size(19, 20);
            this.agvLabel1.TabIndex = 179;
            this.agvLabel1.Text = "1";
            this.agvLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.agvLabel1.Visible = false;
            // 
            // agvHome2
            // 
            this.agvHome2.BackColor = System.Drawing.Color.Transparent;
            this.agvHome2.Image = global::SampleUI_SamsungAGV.Properties.Resources.AGVC;
            this.agvHome2.Location = new System.Drawing.Point(824, 78);
            this.agvHome2.Margin = new System.Windows.Forms.Padding(1);
            this.agvHome2.Name = "agvHome2";
            this.agvHome2.Size = new System.Drawing.Size(48, 65);
            this.agvHome2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.agvHome2.TabIndex = 178;
            this.agvHome2.TabStop = false;
            this.agvHome2.Visible = false;
            // 
            // agvHome1
            // 
            this.agvHome1.BackColor = System.Drawing.Color.Transparent;
            this.agvHome1.Image = global::SampleUI_SamsungAGV.Properties.Resources.AGVC;
            this.agvHome1.Location = new System.Drawing.Point(772, 78);
            this.agvHome1.Margin = new System.Windows.Forms.Padding(1);
            this.agvHome1.Name = "agvHome1";
            this.agvHome1.Size = new System.Drawing.Size(48, 65);
            this.agvHome1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.agvHome1.TabIndex = 177;
            this.agvHome1.TabStop = false;
            this.agvHome1.Visible = false;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox13.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox13.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(785, 155);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(75, 17);
            this.textBox13.TabIndex = 170;
            this.textBox13.Text = "HOME BASE";
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.Color.PapayaWhip;
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox12.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox12.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(50, 176);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(96, 21);
            this.textBox12.TabIndex = 169;
            this.textBox12.Text = "LIFTER";
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.Lime;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox11.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(188, 107);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(96, 21);
            this.textBox11.TabIndex = 165;
            this.textBox11.Text = "OPERATOR";
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wipFull2
            // 
            this.wipFull2.AllowFocused = false;
            this.wipFull2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.wipFull2.AutoSizeHeight = true;
            this.wipFull2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.wipFull2.BorderRadius = 28;
            this.wipFull2.Image = ((System.Drawing.Image)(resources.GetObject("wipFull2.Image")));
            this.wipFull2.IsCircle = false;
            this.wipFull2.Location = new System.Drawing.Point(29, 60);
            this.wipFull2.Name = "wipFull2";
            this.wipFull2.Size = new System.Drawing.Size(56, 56);
            this.wipFull2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.wipFull2.TabIndex = 168;
            this.wipFull2.TabStop = false;
            this.wipFull2.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Custom;
            this.wipFull2.Visible = false;
            // 
            // wipFull1
            // 
            this.wipFull1.AllowFocused = false;
            this.wipFull1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.wipFull1.AutoSizeHeight = true;
            this.wipFull1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.wipFull1.BorderRadius = 28;
            this.wipFull1.Image = ((System.Drawing.Image)(resources.GetObject("wipFull1.Image")));
            this.wipFull1.IsCircle = false;
            this.wipFull1.Location = new System.Drawing.Point(110, 60);
            this.wipFull1.Name = "wipFull1";
            this.wipFull1.Size = new System.Drawing.Size(56, 56);
            this.wipFull1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.wipFull1.TabIndex = 167;
            this.wipFull1.TabStop = false;
            this.wipFull1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Custom;
            this.wipFull1.Visible = false;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox10.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox10.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(31, 124);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(55, 17);
            this.textBox10.TabIndex = 166;
            this.textBox10.Text = "OUT 2";
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox9.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(112, 124);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(55, 17);
            this.textBox9.TabIndex = 165;
            this.textBox9.Text = "OUT 1";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox8.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(312, 155);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(55, 17);
            this.textBox8.TabIndex = 165;
            this.textBox8.Text = "IN 6";
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox7.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(390, 155);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(55, 17);
            this.textBox7.TabIndex = 165;
            this.textBox7.Text = "IN 5";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox6.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(468, 155);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(55, 17);
            this.textBox6.TabIndex = 165;
            this.textBox6.Text = "IN 4";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox5.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(546, 155);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(55, 17);
            this.textBox5.TabIndex = 165;
            this.textBox5.Text = "IN 3";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(624, 155);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(55, 17);
            this.textBox4.TabIndex = 165;
            this.textBox4.Text = "IN 2";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(702, 155);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(55, 17);
            this.textBox3.TabIndex = 165;
            this.textBox3.Text = "IN 1";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wip1
            // 
            this.wip1.AllowFocused = false;
            this.wip1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.wip1.AutoSizeHeight = true;
            this.wip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.wip1.BorderRadius = 28;
            this.wip1.Image = ((System.Drawing.Image)(resources.GetObject("wip1.Image")));
            this.wip1.IsCircle = false;
            this.wip1.Location = new System.Drawing.Point(701, 93);
            this.wip1.Name = "wip1";
            this.wip1.Size = new System.Drawing.Size(56, 56);
            this.wip1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.wip1.TabIndex = 143;
            this.wip1.TabStop = false;
            this.wip1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Custom;
            this.wip1.Visible = false;
            // 
            // labelPosition
            // 
            this.labelPosition.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelPosition.BackColor = System.Drawing.Color.Gainsboro;
            this.labelPosition.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelPosition.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelPosition.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelPosition.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.labelPosition.Location = new System.Drawing.Point(18, 8);
            this.labelPosition.Name = "labelPosition";
            this.labelPosition.Size = new System.Drawing.Size(161, 41);
            this.labelPosition.TabIndex = 148;
            this.labelPosition.Text = "AGV Position";
            this.labelPosition.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wip2
            // 
            this.wip2.AllowFocused = false;
            this.wip2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.wip2.AutoSizeHeight = true;
            this.wip2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.wip2.BorderRadius = 28;
            this.wip2.Image = ((System.Drawing.Image)(resources.GetObject("wip2.Image")));
            this.wip2.IsCircle = false;
            this.wip2.Location = new System.Drawing.Point(622, 93);
            this.wip2.Name = "wip2";
            this.wip2.Size = new System.Drawing.Size(56, 56);
            this.wip2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.wip2.TabIndex = 142;
            this.wip2.TabStop = false;
            this.wip2.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Custom;
            this.wip2.Visible = false;
            // 
            // wip3
            // 
            this.wip3.AllowFocused = false;
            this.wip3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.wip3.AutoSizeHeight = true;
            this.wip3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.wip3.BorderRadius = 28;
            this.wip3.Image = ((System.Drawing.Image)(resources.GetObject("wip3.Image")));
            this.wip3.IsCircle = false;
            this.wip3.Location = new System.Drawing.Point(543, 93);
            this.wip3.Name = "wip3";
            this.wip3.Size = new System.Drawing.Size(56, 56);
            this.wip3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.wip3.TabIndex = 141;
            this.wip3.TabStop = false;
            this.wip3.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Custom;
            this.wip3.Visible = false;
            // 
            // wip4
            // 
            this.wip4.AllowFocused = false;
            this.wip4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.wip4.AutoSizeHeight = true;
            this.wip4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.wip4.BorderRadius = 28;
            this.wip4.Image = ((System.Drawing.Image)(resources.GetObject("wip4.Image")));
            this.wip4.IsCircle = false;
            this.wip4.Location = new System.Drawing.Point(464, 93);
            this.wip4.Name = "wip4";
            this.wip4.Size = new System.Drawing.Size(56, 56);
            this.wip4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.wip4.TabIndex = 140;
            this.wip4.TabStop = false;
            this.wip4.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Custom;
            this.wip4.Visible = false;
            // 
            // wip5
            // 
            this.wip5.AllowFocused = false;
            this.wip5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.wip5.AutoSizeHeight = true;
            this.wip5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.wip5.BorderRadius = 28;
            this.wip5.Image = ((System.Drawing.Image)(resources.GetObject("wip5.Image")));
            this.wip5.IsCircle = false;
            this.wip5.Location = new System.Drawing.Point(385, 93);
            this.wip5.Name = "wip5";
            this.wip5.Size = new System.Drawing.Size(56, 56);
            this.wip5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.wip5.TabIndex = 139;
            this.wip5.TabStop = false;
            this.wip5.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Custom;
            this.wip5.Visible = false;
            // 
            // wip6
            // 
            this.wip6.AllowFocused = false;
            this.wip6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.wip6.AutoSizeHeight = true;
            this.wip6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.wip6.BorderRadius = 28;
            this.wip6.Image = ((System.Drawing.Image)(resources.GetObject("wip6.Image")));
            this.wip6.IsCircle = false;
            this.wip6.Location = new System.Drawing.Point(309, 93);
            this.wip6.Name = "wip6";
            this.wip6.Size = new System.Drawing.Size(56, 56);
            this.wip6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.wip6.TabIndex = 138;
            this.wip6.TabStop = false;
            this.wip6.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Custom;
            this.wip6.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox2.Font = new System.Drawing.Font("DDTW00-CondensedSemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(179, 51);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(115, 23);
            this.textBox2.TabIndex = 136;
            this.textBox2.Text = "WIP AREA";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.Color.Gainsboro;
            this.pictureBox25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox25.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox25.Image")));
            this.pictureBox25.ImageLocation = "";
            this.pictureBox25.Location = new System.Drawing.Point(18, 51);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(858, 167);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox25.TabIndex = 135;
            this.pictureBox25.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.pictureBox1.Location = new System.Drawing.Point(776, 506);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(670, 89);
            this.pictureBox1.TabIndex = 171;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.pictureBox11.Location = new System.Drawing.Point(776, 16);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(670, 89);
            this.pictureBox11.TabIndex = 175;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.pictureBox10.Location = new System.Drawing.Point(776, 113);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(670, 89);
            this.pictureBox10.TabIndex = 174;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.pictureBox9.Location = new System.Drawing.Point(776, 209);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(670, 89);
            this.pictureBox9.TabIndex = 173;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.pictureBox5.Location = new System.Drawing.Point(776, 308);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(670, 89);
            this.pictureBox5.TabIndex = 172;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.pictureBox12.Location = new System.Drawing.Point(776, 405);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(670, 89);
            this.pictureBox12.TabIndex = 176;
            this.pictureBox12.TabStop = false;
            // 
            // standby4
            // 
            this.standby4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(128)))));
            this.standby4.Location = new System.Drawing.Point(31, 209);
            this.standby4.Name = "standby4";
            this.standby4.Size = new System.Drawing.Size(670, 89);
            this.standby4.TabIndex = 101;
            this.standby4.TabStop = false;
            // 
            // send4
            // 
            this.send4.Location = new System.Drawing.Point(31, 209);
            this.send4.Name = "send4";
            this.send4.Size = new System.Drawing.Size(670, 89);
            this.send4.TabIndex = 179;
            this.send4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Gainsboro;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox3.ImageLocation = "";
            this.pictureBox3.Location = new System.Drawing.Point(992, 735);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(510, 245);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 134;
            this.pictureBox3.TabStop = false;
            // 
            // stopLine1
            // 
            this.stopLine1.BackColor = System.Drawing.Color.Black;
            this.stopLine1.Location = new System.Drawing.Point(1074, 630);
            this.stopLine1.Margin = new System.Windows.Forms.Padding(2);
            this.stopLine1.Name = "stopLine1";
            this.stopLine1.Size = new System.Drawing.Size(4, 350);
            this.stopLine1.TabIndex = 17;
            this.stopLine1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(77)))), ((int)(((byte)(162)))));
            this.ClientSize = new System.Drawing.Size(1920, 1080);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.detailDeliveryButton);
            this.Controls.Add(this.bunifuLabel6);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.detailErrorButton);
            this.Controls.Add(this.bunifuPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.bunifuPanel1.ResumeLayout(false);
            this.bunifuPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.bunifuPanel2.ResumeLayout(false);
            this.bunifuPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.agvIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stanbyLine1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopLine3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopLine2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goLine2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TNP02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TNP01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TNP03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.standbyLine2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.standbyLine3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SMD03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.send6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.send5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.send3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.send2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.send1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goLine1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.idleSmd1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.standbyWip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.agvHome2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agvHome1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wipFull2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wipFull1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wip6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.standby4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.send4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopLine1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel1;
        private Bunifu.UI.WinForms.BunifuDataGridView gridViewStatus;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel2;
        private Bunifu.UI.WinForms.BunifuDataGridView gridViewDS;
        private Bunifu.UI.WinForms.BunifuDataGridView gridViewError;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_TimeError;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_AGV_Error;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_Message;
        private System.Windows.Forms.PictureBox standbyLine2;
        private Bunifu.Framework.UI.BunifuThinButton2 closeButton;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox stopLine1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private Bunifu.Framework.UI.BunifuThinButton2 detailDeliveryButton;
        private Bunifu.Framework.UI.BunifuThinButton2 detailErrorButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private Bunifu.UI.WinForms.BunifuLabel dateLabel;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox standbyLine3;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox SMD02;
        private System.Windows.Forms.PictureBox SMD03;
        private System.Windows.Forms.PictureBox SMD05;
        private System.Windows.Forms.PictureBox SMD04;
        private System.Windows.Forms.PictureBox SMD06;
        private System.Windows.Forms.PictureBox TNP02;
        private System.Windows.Forms.PictureBox TNP01;
        private System.Windows.Forms.PictureBox TNP03;
        private System.Windows.Forms.PictureBox SMD09;
        private System.Windows.Forms.PictureBox SMD08;
        private System.Windows.Forms.PictureBox SMD01;
        private System.Windows.Forms.PictureBox SMD07;
        private System.Windows.Forms.PictureBox agvIcon;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.PictureBox send1;
        private System.Windows.Forms.PictureBox standby1;
        private System.Windows.Forms.PictureBox standby2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox standby6;
        private System.Windows.Forms.PictureBox standby5;
        private System.Windows.Forms.PictureBox standby4;
        private System.Windows.Forms.PictureBox standby3;
        private System.Windows.Forms.PictureBox send6;
        private System.Windows.Forms.PictureBox send5;
        private System.Windows.Forms.PictureBox send3;
        private System.Windows.Forms.PictureBox send2;
        private System.Windows.Forms.PictureBox standbyWip;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.PictureBox goLine1;
        private System.Windows.Forms.PictureBox stanbyLine1;
        private System.Windows.Forms.PictureBox stopLine2;
        private System.Windows.Forms.PictureBox goLine2;
        private System.Windows.Forms.PictureBox stopLine3;
        private System.Windows.Forms.PictureBox idleSmd1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_Time_Deliv;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_AGV_Delivery;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_Delivery;
        private Bunifu.UI.WinForms.BunifuProgressBar batteryLevel1;
        private System.Windows.Forms.Label batValue1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbox6;
        private System.Windows.Forms.TextBox tbox1;
        private System.Windows.Forms.TextBox tbox2;
        private System.Windows.Forms.TextBox tbox3;
        private System.Windows.Forms.TextBox tbox4;
        private System.Windows.Forms.TextBox tbox5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox homeBox;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox wipOut2;
        private System.Windows.Forms.TextBox wipOut1;
        private System.Windows.Forms.TextBox wipIn6;
        private System.Windows.Forms.TextBox wipIn5;
        private System.Windows.Forms.TextBox wipIn4;
        private System.Windows.Forms.TextBox wipIn3;
        private System.Windows.Forms.TextBox wipIn2;
        private System.Windows.Forms.TextBox wipIn1;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Battery;
        private System.Windows.Forms.Label labelPosition;
        private System.Windows.Forms.TextBox rfid31;
        private System.Windows.Forms.TextBox rfid1;
        private System.Windows.Forms.TextBox rfid34;
        private System.Windows.Forms.TextBox rfid16;
        private System.Windows.Forms.TextBox rfid42;
        private System.Windows.Forms.TextBox rfid40;
        private System.Windows.Forms.TextBox rfid38;
        private System.Windows.Forms.TextBox rfid25;
        private System.Windows.Forms.TextBox rfid24;
        private System.Windows.Forms.TextBox rfid23;
        private System.Windows.Forms.TextBox rfid22;
        private System.Windows.Forms.TextBox rfid21;
        private System.Windows.Forms.TextBox rfid20;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.PictureBox pictureBox25;
        private Bunifu.UI.WinForms.BunifuPictureBox wip6;
        private Bunifu.UI.WinForms.BunifuPictureBox wip1;
        private Bunifu.UI.WinForms.BunifuPictureBox wip2;
        private Bunifu.UI.WinForms.BunifuPictureBox wip3;
        private Bunifu.UI.WinForms.BunifuPictureBox wip4;
        private Bunifu.UI.WinForms.BunifuPictureBox wip5;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private Bunifu.UI.WinForms.BunifuPictureBox wipFull2;
        private Bunifu.UI.WinForms.BunifuPictureBox wipFull1;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox tbox7;
        private System.Windows.Forms.TextBox tbox8;
        private System.Windows.Forms.TextBox tbox9;
        private System.Windows.Forms.TextBox tbox12;
        private System.Windows.Forms.TextBox tbox11;
        private System.Windows.Forms.TextBox tbox10;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.PictureBox agvHome1;
        private System.Windows.Forms.PictureBox agvHome2;
        private System.Windows.Forms.TextBox rfid8;
        private System.Windows.Forms.TextBox rfid9;
        private System.Windows.Forms.Label agvLabel2;
        private System.Windows.Forms.Label agvLabel1;
        private System.Windows.Forms.PictureBox send4;
        private System.Windows.Forms.TextBox rfid2;
        private System.Windows.Forms.TextBox rfid5;
        private System.Windows.Forms.TextBox rfid10;
        private System.Windows.Forms.TextBox rfid32;
        private System.Windows.Forms.TextBox rfid33;
        private System.Windows.Forms.TextBox rfid37;
        private System.Windows.Forms.TextBox rfid15;
        private System.Windows.Forms.TextBox rfid39;
        private System.Windows.Forms.TextBox rfid41;
        private System.Windows.Forms.TextBox rfid4;
        private System.Windows.Forms.TextBox rfid19;
        private System.Windows.Forms.TextBox rfid11;
        private System.Windows.Forms.TextBox textBox14;
    }
}

